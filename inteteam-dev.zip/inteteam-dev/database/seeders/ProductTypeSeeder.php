<?php

namespace Database\Seeders;

use App\Models\ProductType;
use Illuminate\Database\Seeder;
use Illuminate\Support\Str;

class ProductTypeSeeder extends Seeder
{
    /**
     * Run the database seeds.
     *
     * @return void
     */
    public function run()
    {
        $data = [
            'Hardware',
            'Software',
            'Service'
        ];
        foreach ($data as $value) {
            ProductType::create([
                'name' => $value,
                'slug' => Str::slug($value)
            ]);
        }

    }
}
