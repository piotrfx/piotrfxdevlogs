<?php

namespace Database\Seeders;

use App\Models\SupportPriority;
use Illuminate\Database\Seeder;

class SupportPrioritySeeder extends Seeder
{
    /**
     * Run the database seeds.
     *
     * @return void
     */
    public function run()
    {
        $data = [
            'Low',
            'Normal',
            'Urgent'
        ];
        foreach ($data as $item) {
            SupportPriority::create([
                'name' => $item
            ]);
        }
    }
}
