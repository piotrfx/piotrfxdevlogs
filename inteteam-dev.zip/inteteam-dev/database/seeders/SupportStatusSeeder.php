<?php

namespace Database\Seeders;

use App\Models\SupportStatus;
use Illuminate\Database\Seeder;
use Illuminate\Support\Str;

class SupportStatusSeeder extends Seeder
{
    /**
     * Run the database seeds.
     *
     * @return void
     */
    public function run()
    {
        $data = [
            'Open', 'In Progress', 'Closed'
        ];

        foreach ($data as $item) {
            SupportStatus::create([
                'name' => $item,
                'slug' => Str::slug($item)
            ]);
        }
    }
}
