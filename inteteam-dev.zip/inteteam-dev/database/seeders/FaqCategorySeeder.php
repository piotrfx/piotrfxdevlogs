<?php

namespace Database\Seeders;

use Illuminate\Database\Seeder;

class FaqCategorySeeder extends Seeder
{
    /**
     * Run the database seeds.
     *
     * @return void
     */
    public function run()
    {
        //First category example:
        \DB::table('faq_categories')->insert([
            'name' => 'General questions about the platform',
            'slug' => 'general-questions-about-the-platform'
        ]);
        //Second category example:
        \DB::table('faq_categories')->insert([
            'name' => 'Questions about accounts',
            'slug' => 'questions-about-accounts'
        ]);
        //Third category example:
        \DB::table('faq_categories')->insert([
            'name' => 'Affiliate questions',
            'slug' => 'affiliate-questions'
        ]);
        //Fourth category example:
        \DB::table('faq_categories')->insert([
            'name' => 'Compensation questions',
            'slug' => 'compensation-questions'
        ]);
        //Fifth category example:
        \DB::table('faq_categories')->insert([
            'name' => 'Shop questions',
            'slug' => 'shop-questions'
        ]);
    }
}
