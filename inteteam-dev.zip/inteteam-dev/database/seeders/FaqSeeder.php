<?php

namespace Database\Seeders;

use Illuminate\Database\Seeder;


class FaqSeeder extends Seeder
{
    /**
     * Run the database seeds.
     *
     * @return void
     */
    public function run()
    {
        //First seed example:
        \DB::table('faqs')->insert([
            'faq_category_id' => '1',
            'question' => 'question text example 1',
            'answer' => 'an example of the answer 1 :)'
        ]);

        //Second seed example:
        \DB::table('faqs')->insert([
            'faq_category_id' => '5',
            'question' => 'question text example 2',
            'answer' => '2nd example of an answer :)'
        ]);

        //Third seed example:
        \DB::table('faqs')->insert([
            'faq_category_id' => '3',
            'question' => 'question text example 3',
            'answer' => 'an example of an answer 3 :)'
        ]);

        //Forth seed example:
        \DB::table('faqs')->insert([
            'faq_category_id' => '3',
            'question' => 'question text example 4',
            'answer' => 'example of an answer 4 :)'
        ]);
    }
}
