<?php

namespace Database\Seeders;

use Illuminate\Database\Seeder;

class DatabaseSeeder extends Seeder
{
    /**
     * Seed the application's database.
     *
     * @return void
     */
    public function run()
    {
        //\App\Models\User::factory(10)->create();
        $this->call(WalletsTableSeeder::class);
        $this->call(RolesSeeder::class);
        $this->call(FaqCategorySeeder::class);
        $this->call(FaqSeeder::class);
        $this->call(ProductTypeSeeder::class);
        $this->call(CountrySeeder::class);
        //\App\Models\Product::factory(10)->create();
        $this->call(UserTableSeeder::class);
        $this->call(SupportPrioritySeeder::class);
        $this->call(SupportStatusSeeder::class);
        $this->call(WalletsTableSeeder::class);
        $this->call(MemberInviteSeeder::class);
    }
}
