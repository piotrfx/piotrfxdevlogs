<?php

namespace Database\Seeders;

use App\Models\User;
use Illuminate\Database\Seeder;
use Illuminate\Support\Str;
use Illuminate\Support\Facades\File;
use Illuminate\Support\Facades\Storage;

class UserTableSeeder extends Seeder
{
    /**
     * Run the database seeds.
     *
     * @return void
     */
    public function run()
    {
        Storage::makeDirectory('media/images/avatar/');
        File::copy(base_path('public\vendor\avatar\default.png'), Storage::path('media/images/avatar/default.png'));

        $me = User::create([

            'first_name'        => 'Tomasz',
            'last_name'         => ' Drabik',
            'user_name'         => 'DeveloperZONE',
            'email'             => 'tdrabik@developerzone.eu',
            'email_verified_at' => now(),
            'password'          => 'password',
            'remember_token'    => Str::random(10),
        ]);
        $me->assignRole(['Member', 'User','Admin']);
        $me->profile()->create();
        $me1 = User::create([

            'first_name'        => 'Yoda',
            'last_name'         => 'Master',
            'user_name'         => 'DeveloperZONE1',
            'email'             => 'tdrabik12@developerzone.eu',
            'email_verified_at' => now(),
            'password'          => 'password',
            'remember_token'    => Str::random(10),
        ]);
        $me1->assignRole(['Support']);
        $me1->profile()->create();
        $me2 = User::create([

            'first_name'        => 'Padle',
            'last_name'         => 'Stravbord',
            'user_name'         => 'Padle',
            'email'             => 'padlemen@gmail.com',
            'email_verified_at' => now(),
            'password'          => 'password',
            'remember_token'    => Str::random(10),
        ]);
        $me2->assignRole(['Member', 'User']);
        $me2->profile()->create();
        $me3 = User::create([

            'first_name'        => 'Piotr',
            'last_name'         => 'Ficner',
            'user_name'         => 'Profic',
            'email'             => 'shopscot@gmaill.com',
            'email_verified_at' => now(),
            'password'          => 'Qazxsw12',
            'remember_token'    => Str::random(10),
        ]);
        $me3->assignRole(['Admin']);
        $me3->profile()->create();

        $me4 = User::create([

            'first_name'        => 'Patryk',
            'last_name'         => 'Kacprowicz',
            'user_name'         => 'Goooldzik',
            'email'             => 'patryk.k@inte.team',
            'email_verified_at' => now(),
            'password'          => 'password',
            'remember_token'    => Str::random(10),
        ]);
        $me4->assignRole(['Member', 'User','Admin']);
        $me4->profile()->create();
    }
}
