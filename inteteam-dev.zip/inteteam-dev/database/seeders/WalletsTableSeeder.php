<?php
namespace Database\Seeders;
use Illuminate\Database\Seeder;
use App\Models\Wallet;
use App\Models\User;

class WalletsTableSeeder extends Seeder
{
    /**
     * Run the database seeds.
     *
     * @return void
     */
    public function run()
    {
        $users = User::get();
        foreach($users as $user)
            Wallet::create([
                'user_id' => $user->id,
                'available_amount' => 100,
                'total_amount' => 500
            ]);
    }
}
