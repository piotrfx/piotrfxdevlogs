<?php

namespace Database\Factories;

use App\Models\SupportCategory;
use App\Models\SupportPriority;
use App\Models\SupportStatus;
use App\Models\SupportTicket;
use App\Models\User;
use Illuminate\Database\Eloquent\Factories\Factory;
use Illuminate\Support\Carbon;

class SupportTicketFactory extends Factory
{
    protected $model = SupportTicket::class;

    public function definition(): array
    {
        return [
            'ticket_id'  => $this->faker->randomNumber(5),
            'uuid'       => $this->faker->uuid(),
            'title'      => $this->faker->words(5,true),
            'message'    => $this->faker->sentence(),
            'created_at' => Carbon::now(),
            'updated_at' => Carbon::now(),
            'user_id'             => function () {
                return User::factory()->create()->id;
            },
            'agent_id'            => function () {
                return User::factory()->create()->id;
            },
            'support_status_id'   => function () {
                return SupportStatus::factory()->create()->id;
            },
            'support_priority_id' => function () {
                return SupportPriority::factory()->create()->id;
            },
            'support_category_id' => function () {
                return SupportCategory::factory()->create()->id;
            },
        ];
    }
}
