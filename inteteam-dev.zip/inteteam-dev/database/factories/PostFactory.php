<?php

namespace Database\Factories;

use App\Models\Category;
use App\Models\Post;
use App\Models\User;
use Illuminate\Database\Eloquent\Factories\Factory;
use Illuminate\Support\Carbon;

class PostFactory extends Factory
{
    protected $model = Post::class;

    /**
     * Define the model's default state.
     *
     * @return array
     */
    public function definition()
    {
        return [
            'title'      => $this->faker->word(),
            'slug'       => $this->faker->slug(),
            'body'       => $this->faker->word(),
            'image_path' => $this->faker->imageUrl(),
            'status'     => $this->faker->boolean(),
            'created_at' => Carbon::now(),
            'updated_at' => Carbon::now(),

            'category_id' => function () {
                return Category::factory()->create()->id;
            },
            'user_id'     => function () {
                return User::factory()->create()->id;
            },
        ];
    }
}
