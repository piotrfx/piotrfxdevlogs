<?php

namespace Database\Factories;

use App\Models\SupportTicketMessage;
use App\Models\User;
use Illuminate\Database\Eloquent\Factories\Factory;
use Illuminate\Support\Carbon;

class SupportTicketMessageFactory extends Factory
{
    protected $model = SupportTicketMessage::class;

    /**
     * Define the model's default state.
     *
     * @return array
     */
    public function definition()
    {
        return [
            'support_ticket_id' => rand(1,2),
            'message'           => $this->faker->sentence(10,true),
            'created_at'        => Carbon::now(),
            'updated_at'        => Carbon::now(),

            'user_id' => rand(1,100),
        ];
    }
}
