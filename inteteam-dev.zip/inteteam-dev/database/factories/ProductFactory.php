<?php

namespace Database\Factories;

use App\Models\Product;
use App\Models\ProductCategory;
use App\Models\ProductType;
use App\Models\Supplier;
use App\Models\User;
use Illuminate\Database\Eloquent\Factories\Factory;
use Illuminate\Support\Carbon;

class ProductFactory extends Factory
{
    protected $model = Product::class;


    /**
     * Define the model's default state.
     *
     * @return array
     */
    public function definition()
    {
        return [
            'name'            => $this->faker->name(),
            'slug'            => $this->faker->slug(),
            'image_path'      => $this->faker->word(),
            'price'           => $this->faker->randomNumber(4),
            'sku'             => $this->faker->word(),
            'qty'             => $this->faker->randomNumber(3),

            'description'     => $this->faker->text(),
            'content'         => $this->faker->word(),
            'status'          => $this->faker->boolean(),
            'available_at'    => Carbon::now(),
            'created_at'      => Carbon::now(),
            'updated_at'      => Carbon::now(),
            'product_category_id' => function () {
                return ProductCategory::factory()->create()->id;
            },
            'user_id'             => function () {
                return User::factory()->create()->id;
            },
            'product_type_id'     => function () {
                return ProductType::factory()->create()->id;
            },
            'supplier_id'         => function () {
                return Supplier::factory()->create()->id;
            },
        ];
    }
}
