<?php

namespace Database\Factories;

use App\Models\ProductCategory;
use Illuminate\Database\Eloquent\Factories\Factory;
use Illuminate\Support\Carbon;

class ProductCategoryFactory extends Factory
{
    protected $model = ProductCategory::class;

    /**
     * Define the model's default state.
     *
     * @return array
     */
    public function definition()
    {
        return [
            'title'          => $this->faker->word(),
            'slug'           => $this->faker->slug(),
            'description'    => $this->faker->text(),
            'image_path'     => $this->faker->imageUrl(),
            'status'         => $this->faker->boolean(),
            'sort'           => $this->faker->randomNumber(2),
            'created_at'     => Carbon::now(),
            'updated_at'     => Carbon::now(),

            'parent_id' => 0,
        ];
    }
}
