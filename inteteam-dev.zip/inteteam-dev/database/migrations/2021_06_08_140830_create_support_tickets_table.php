<?php

use Illuminate\Database\Migrations\Migration;
use Illuminate\Database\Schema\Blueprint;
use Illuminate\Support\Facades\Schema;

class CreateSupportTicketsTable extends Migration
{
    public function up()
    {
        Schema::create('support_tickets', function (Blueprint $table) {
            $table->bigIncrements('id');
            $table->string('ticket_id')->nullable();
            $table->uuid('uuid');
            $table->string('title');
            $table->text('message');
            $table->foreignId('user_id')->constrained()->cascadeOnDelete();
            $table->unsignedBigInteger('agent_id')->nullable();
            $table->foreign('agent_id')
                ->references('id')
                ->on('users')
                ->cascadeOnDelete();
            $table->foreignId('support_status_id')->constrained()->cascadeOnDelete();
            $table->foreignId('support_priority_id')->constrained()->cascadeOnDelete();
            $table->foreignId('support_category_id')->constrained()->cascadeOnDelete();
            $table->timestamps();
        });
    }

    public function down()
    {
        Schema::dropIfExists('support_tickets');
    }
}
