<?php

use Illuminate\Database\Migrations\Migration;
use Illuminate\Database\Schema\Blueprint;
use Illuminate\Support\Facades\Schema;

class AddFieldToPostComments extends Migration
{
    public function up()
    {
        Schema::table('post_comments', function (Blueprint $table) {
            $table->boolean('is_disabled')->after('post_id')->default(false);
        });
    }

    public function down()
    {
        Schema::table('post_comments', function (Blueprint $table) {
            $table->dropColumn('is_disabled');
        });
    }
}
