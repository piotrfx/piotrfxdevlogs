<?php

use Illuminate\Database\Migrations\Migration;
use Illuminate\Database\Schema\Blueprint;
use Illuminate\Support\Facades\Schema;

class AddBankAccountFieldsToSuppilerTable extends Migration
{
    /**
     * Run the migrations.
     *
     * @return void
     */
    public function up()
    {
        Schema::table('suppliers', function (Blueprint $table) {
            $table->text('bank_name');
            $table->text('sort_code');
            $table->text('account_number');
            $table->text('registration_number');
            $table->dropColumn('bank_account');
        });
    }

    /**
     * Reverse the migrations.
     *
     * @return void
     */
    public function down()
    {
        Schema::table('suppliers', function (Blueprint $table) {
            $table->dropColumn('bank_name');
            $table->dropColumn('sort_code');
            $table->dropColumn('account_number');
            $table->dropColumn('registration_number');
            $table->text('bank_account');
        });
    }
}
