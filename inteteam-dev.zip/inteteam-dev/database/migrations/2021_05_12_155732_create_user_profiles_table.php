<?php

use Illuminate\Database\Migrations\Migration;
use Illuminate\Database\Schema\Blueprint;
use Illuminate\Support\Facades\Schema;

class CreateUserProfilesTable extends Migration
{
    public function up()
    {
        Schema::create('user_profiles', function (Blueprint $table) {
            $table->bigIncrements('id');
            $table->foreignId('user_id')->constrained()->cascadeOnDelete();
            $table->unsignedBigInteger('delivery_address_id')->nullable();
            $table->foreign('delivery_address_id')->on('user_delivery_addresses')->references('id')->nullOnDelete();
            $table->unsignedBigInteger('reply_address_id')->nullable();
            $table->foreign('reply_address_id')->on('user_delivery_addresses')->references('id')->nullOnDelete();
            $table->string('avatar')->nullable();
            $table->string('phone')->nullable();
            $table->text('description')->nullable();
            $table->timestamps();
        });
    }
    public function down()
    {
        Schema::dropIfExists('user_profiles');
    }
}
