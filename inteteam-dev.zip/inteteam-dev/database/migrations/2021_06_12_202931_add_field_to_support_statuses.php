<?php

use Illuminate\Database\Migrations\Migration;
use Illuminate\Database\Schema\Blueprint;
use Illuminate\Support\Facades\Schema;

class AddFieldToSupportStatuses extends Migration
{
    public function up()
    {
        Schema::table('support_statuses', function (Blueprint $table) {
            $table->string('slug')->after('name');
        });
    }

    public function down()
    {
        Schema::table('support_statuses', function (Blueprint $table) {
            $table->dropColumn('slug');
        });
    }
}
