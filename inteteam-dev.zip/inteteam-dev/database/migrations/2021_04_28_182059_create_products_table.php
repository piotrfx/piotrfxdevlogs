<?php

use Illuminate\Database\Migrations\Migration;
use Illuminate\Database\Schema\Blueprint;
use Illuminate\Support\Facades\Schema;

class CreateProductsTable extends Migration
{
    public function up()
    {
        Schema::create('products', function (Blueprint $table) {
            $table->bigIncrements('id');
            $table->string('name')->unique();
            $table->string('slug');
            $table->foreignId('product_category_id')->constrained()->cascadeOnDelete();
            $table->foreignId('user_id')->constrained()->cascadeOnDelete();
            $table->string('image_path');
            $table->unsignedInteger('price');
            $table->foreignId('product_type_id')->constrained()->cascadeOnDelete();
            $table->string('sku')->nullable();
            $table->unsignedInteger('qty')->default(0)->comment('0 means unlimited');
            $table->text('short_description');
            $table->text('long_description');
            $table->longText('content')->nullable();
            $table->foreignId('supplier_id')->constrained()->cascadeOnDelete();
            $table->boolean('status')->default(false);
            $table->date('available_at')->nullable();
            $table->string('colour')->nullable();
            $table->date('expiry_date')->nullable();
            $table->timestamps();
        });
    }

    public function down()
    {
        Schema::dropIfExists('products');
    }
}
