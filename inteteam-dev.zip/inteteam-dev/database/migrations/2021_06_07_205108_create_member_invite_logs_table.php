<?php

use Illuminate\Database\Migrations\Migration;
use Illuminate\Database\Schema\Blueprint;
use Illuminate\Support\Facades\Schema;

class CreateMemberInviteLogsTable extends Migration
{
    public function up()
    {
        Schema::create('member_invite_logs', function (Blueprint $table) {
            $table->bigIncrements('id');
            $table->unsignedBigInteger('inviting_id');
            $table->unsignedBigInteger('invited_id');
            $table->timestamps();
            $table->foreign('inviting_id')->references('id')->on('users')->cascadeOnDelete();
            $table->foreign('invited_id')->references('id')->on('users')->cascadeOnDelete();
        });
    }

    public function down()
    {
        Schema::dropIfExists('member_invite_logs');
    }
}
