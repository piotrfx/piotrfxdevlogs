<?php

use Illuminate\Database\Migrations\Migration;
use Illuminate\Database\Schema\Blueprint;
use Illuminate\Support\Facades\Schema;

class CreateSuppliersTable extends Migration
{
    public function up()
    {
        Schema::create('suppliers', function (Blueprint $table) {
            $table->bigIncrements('id');
            $table->string('name')->unique();
            $table->string('slug');
            $table->text('description');
            $table->string('first_line_address');
            $table->string('second_line_address');
            $table->string('town');
            $table->string('post_code');
            $table->string('contact_email');
            $table->string('contact_phone');
            $table->text('vat_no')->nullable();
            $table->text('bank_account')->nullable();
            $table->text('form_of_payment')->nullable();
            $table->timestamps();
        });
    }

    public function down()
    {
        Schema::dropIfExists('suppliers');
    }
}
