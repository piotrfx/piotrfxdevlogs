<?php
return [
    //define for admins
    'admin' => [
        'role' => [
            'create' => 'Create new role',
            'update' => 'Update role',
            'delete' => 'Delete role',
        ],
        'permission'=>[
            'create'=>'Create new permission',
            'update'=>'Update permission',
            'delete'=>'Delete permission'
        ],
        'tag'=>[
            'create'=>'Create new tag',
            'update'=>'Update tag',
            'delete'=>'Delete tag'
        ],
        'content_management_category'=>[
            'create'=>'Create new content management category',
            'update'=>'Update content management category',
            'delete'=>'Delete content management category'
        ],
        'post'=>[
            'create'=>'Create new post',
            'update'=>'Update post',
            'delete'=>'Delete post'
        ],
        'comment'=>[
            'update'=>'Update comment',
            'delete'=>'Delete comment'
        ],
        'comment_status'=>[
            'status'=>'Comment status'
        ],
        'faq'=>[
            'create'=>'Create new faq',
            'update'=>'Update faq',
            'delete'=>'Delete faq'
        ],
        'faq_category'=>[
            'create'=>'Create new faq category',
            'update'=>'Update faq category',
            'delete'=>'Delete faq category'
        ],
        'page'=>[
            'create'=>'Create new page',
            'update'=>'Update page',
            'delete'=>'Delete page'
        ],
        'product_category'=>[
            'create'=>'Create new product category',
            'update'=>'Update product category',
            'delete'=>'Delete product category'
        ],
        'product'=>[
            'create'=>'Create new product',
            'update'=>'Update product',
            'delete'=>'Delete product'
        ],
        'supplier'=>[
            'create'=>'Create new supplier',
            'update'=>'Update supplier',
            'delete'=>'Delete supplier'
        ],
        'slider'=>[
            'create'=>'Create new slider',
            'update'=>'Update slider',
            'delete'=>'Delete slider'
        ],
        'user'=>[
            'create'=>'Create new user',
            'update'=>'Update user',
            'delete'=>'Delete user'
        ],
        'support'=>[
            'category'=>[
                'create'=>'Create new category',
                'update'=>'Update category',
                'delete'=>'Delete category'
            ]
        ],
        'members'=>[
            'plans'=> [
                'create'=>'Create new plan',
                'update'=>'Update plan',
                'delete'=>'Delete plan'
            ]
        ]
    ]
];
