<?php

namespace App\DataTables\User\Member;


use App\Models\SupportTicket;
use Yajra\DataTables\Html\Column;
use Yajra\DataTables\Services\DataTable;

class SupportDataTable extends DataTable
{
    /**
     * Build DataTable class.
     *
     * @param  mixed  $query  Results from query() method.
     * @return \Yajra\DataTables\DataTableAbstract
     */
    public function dataTable($query)
    {
        return datatables()
            ->eloquent($query)
            ->editColumn('ticket_id',function($model){
                return view('user.member.support.link',compact('model'));
            })
            ->editColumn('status', function ($model) {
                return $model->status->name;
            })
            ->editColumn('priority',function($model){
                return $model->priority->name;
            })
            ->editColumn('agent',function ($model){
                return ($model->agent) ? $model->agent->full_name :'Not Assigned';
            })
//            ->addColumn('action', function(SupportTicket $model){
//            return view('path.to.view',compact('model'));
//            })
            ;
    }

    /**
     * Get query source of dataTable.
     *
     * @param  \\App\SupportTicket $model
     * @return \Illuminate\Database\Eloquent\Builder
     */
    public function query()
    {
        $model = auth()->user()->tickets()
            ->select('agent_id','created_at','support_priority_id','support_status_id','ticket_id','uuid','title')
            ->with('status','priority','agent');
        return $model->newQuery();
    }

    /**
     * Optional method if you want to use html builder.
     *
     * @return \Yajra\DataTables\Html\Builder
     */
    public function html()
    {
        return $this->builder()
            ->setTableId('user-member-support-table')
            ->columns($this->getColumns())
            ->minifiedAjax()
            ->dom('Bfrtlip')
            ->orderBy(5, 'asc');
    }

    /**
     * Get columns.
     *
     * @return array
     */
    protected function getColumns()
    {
        return [
            Column::make('ticket_id'),
            Column::make('title'),
            Column::make('status', 'support_status_id'),
            Column::make('priority','support_priority_id'),
            Column::make('agent','agent_id'),
            Column::make('created_at'),
//            Column::make('updated_at'),
//            Column::computed('action')
//                ->exportable(false)
//                ->printable(false)
//                ->addClass('text-center'),
        ];
    }

    /**
     * Get filename for export.
     *
     * @return string
     */
    protected function filename()
    {
        return 'User-Member-Support_'.date('YmdHis');
    }
}
