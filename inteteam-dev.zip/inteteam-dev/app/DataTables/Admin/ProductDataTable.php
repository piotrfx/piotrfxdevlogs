<?php

namespace App\DataTables\Admin;

use App\Models\Product;
use Yajra\DataTables\Html\Column;
use Yajra\DataTables\Services\DataTable;

class ProductDataTable extends DataTable
{
    /**
     * Build DataTable class.
     *
     * @param  mixed  $query  Results from query() method.
     * @return \Yajra\DataTables\DataTableAbstract
     */
    public function dataTable($query)
    {
        return datatables()
            ->eloquent($query)
            ->editColumn('user', function ($model) {
                return $model->user->full_name;
            })
            ->editColumn('supplier', function ($model) {
                return $model->productSupplier->name;
            })
            ->editColumn('status', function ($model) {
                return ($model->status) ? 'Active' : 'UnActive';
            })
            ->editColumn('product_category', function ($model) {
                return $model->productCategory->title;
            })
            ->addColumn('action', function ($model) {
                return view('admin.products_management.product.actions', compact('model'));
            });
    }

    /**
     * Get query source of dataTable.
     *
     * @param  \App\Models\Admin/Product $model
     * @return \Illuminate\Database\Eloquent\Builder
     */
    public function query(Product $model)
    {
        return Product::with('user', 'productSupplier', 'productCategory')->newQuery();
    }

    /**
     * Optional method if you want to use html builder.
     *
     * @return \Yajra\DataTables\Html\Builder
     */
    public function html()
    {
        return $this->builder()
            ->setTableId('admin-product-table')
            ->columns($this->getColumns())
            ->buttons(["csv", "excel", "pdf", "print"])
            ->minifiedAjax()
            ->dom('Bfrtlip')
            ->orderBy(1, 'asc');
    }

    /**
     * Get columns.
     *
     * @return array
     */
    protected function getColumns()
    {
        return [
            Column::make('id'),
            Column::make('name'),
            Column::make('status'),
            Column::make('price'),
            Column::make('user', 'user_id'),
            Column::make('supplier', 'supplier_id'),
            Column::make('product_category', 'product_category_id'),
            Column::make('colour'),
            Column::make('expiry_date'),
            Column::make('product_type', 'product_type_id'),
            Column::make('created_at'),
            Column::make('updated_at'),
            Column::computed('action')
                ->exportable(false)
                ->printable(false)
                ->addClass('text-center'),
        ];
    }

    /**
     * Get filename for export.
     *
     * @return string
     */
    protected function filename()
    {
        return 'Admin-Product_'.date('YmdHis');
    }
}
