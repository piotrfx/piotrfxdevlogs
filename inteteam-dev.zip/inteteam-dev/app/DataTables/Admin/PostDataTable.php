<?php

namespace App\DataTables\Admin;

use App\Models\Post;
use Yajra\DataTables\Html\Column;
use Yajra\DataTables\Services\DataTable;

class PostDataTable extends DataTable
{
    /**
     * Build DataTable class.
     *
     * @param  mixed  $query  Results from query() method.
     * @return \Yajra\DataTables\DataTableAbstract
     */
    public function dataTable($query)
    {
        return datatables()
            ->eloquent($query)
            ->editColumn('status', function ($model) {
                return ($model->status) ? 'Active' : 'UnActive';
            })
            ->editColumn('user', function ($model) {
                return $model->creator->full_name;
            })
            ->editColumn('category', function ($model) {
                return $model->category->name;
            })
            ->editColumn('action', function ($model) {
                return view('admin.content_management.post.actions', compact('model'));
            });
    }

    /**
     * Get query source of dataTable.
     *
     * @param  \App\Models\Post  $model
     * @return \Illuminate\Database\Eloquent\Builder
     */
    public function query()
    {
        $model = Post::with('creator', 'category')
            ->select(['id', 'title', 'category_id', 'user_id', 'status', 'created_at', 'updated_at']);
        return $model->newQuery();

    }

    /**
     * Optional method if you want to use html builder.
     *
     * @return \Yajra\DataTables\Html\Builder
     */
    public function html()
    {
        return $this->builder()
            ->setTableId('admin-posts-table')
            ->columns($this->getColumns())
            ->buttons(["csv", "excel", "pdf", "print"])
            ->minifiedAjax()
            ->dom('Bfrtlip')
            ->orderBy(1, 'asc');
    }

    /**
     * Get columns.
     *
     * @return array
     */
    protected function getColumns()
    {
        return [
            Column::make('id'),
            Column::make('title'),
            Column::make('category', 'category_id'),
            Column::make('user', 'user_id'),
            Column::make('status'),
            Column::make('created_at'),
            Column::make('updated_at'),
            Column::computed('action')
                ->exportable(false)
                ->printable(false)
                ->width(60)
                ->addClass('text-center'),
        ];
    }

    /**
     * Get filename for export.
     *
     * @return string
     */
    protected function filename()
    {
        return 'Admin-Post_'.date('YmdHis');
    }
}
