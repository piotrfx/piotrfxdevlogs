<?php

namespace App\DataTables\Admin;

use App\Models\SupportTicket;
use Yajra\DataTables\Html\Column;
use Yajra\DataTables\Services\DataTable;

class TicketDataTable extends DataTable
{
    /**
     * Build DataTable class.
     *
     * @param  mixed  $query  Results from query() method.
     * @return \Yajra\DataTables\DataTableAbstract
     */
    public function dataTable($query)
    {
        return datatables()
            ->eloquent($query)
            ->editColumn('ticket_id', function ($model) {
                return view('admin.support.ticket.link', compact('model'));
            })
            ->editColumn('user', function ($model) {
                return $model->creator->full_name;
            })
            ->editColumn('agent', function ($model) {
                return ($model->agent_id) ? $model->agent->full_name : 'NotAssigned';
            })
            ->editColumn('priority', function ($model) {
                return $model->priority->name;
            })
            ->editColumn('status', function ($model) {
                return $model->status->name;
            })
            ->addColumn('action', function (SupportTicket $model) {
                //return view('path.to.view',compact('model'));
            });
    }

    /**
     * Get query source of dataTable.
     *
     * @param  \\Models\SupportTicket $model
     * @return \Illuminate\Database\Eloquent\Builder
     */
    public function query()
    {
        $model = SupportTicket::with('creator', 'priority', 'status', 'agent');
        return $model->newQuery();
    }

    /**
     * Optional method if you want to use html builder.
     *
     * @return \Yajra\DataTables\Html\Builder
     */
    public function html()
    {
        return $this->builder()
            ->setTableId('admin-ticket-table')
            ->columns($this->getColumns())
            ->buttons(["csv", "excel", "pdf", "print"])
            ->minifiedAjax()
            ->dom('Bfrtlip')
            ->orderBy(1, 'asc');
    }

    /**
     * Get columns.
     *
     * @return array
     */
    protected function getColumns()
    {
        return [
            Column::make('ticket_id'),
            Column::make('user', 'user_id'),
            Column::make('agent', 'agent_id'),
            Column::make('priority', 'support_priority_id'),
            Column::make('status', 'support_status_id'),
            Column::make('created_at'),
            Column::make('updated_at'),
        ];
    }

    /**
     * Get filename for export.
     *
     * @return string
     */
    protected function filename()
    {
        return 'Admin-Ticket_'.date('YmdHis');
    }
}
