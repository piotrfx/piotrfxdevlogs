<?php

namespace App\DataTables\Admin;

use App\Models\AuthenticationLog;
use Yajra\DataTables\Html\Column;
use Yajra\DataTables\Services\DataTable;

class AuthenticationLogDataTable extends DataTable
{
    /**
     * Build DataTable class.
     *
     * @param  mixed  $query  Results from query() method.
     * @return \Yajra\DataTables\DataTableAbstract
     */
    public function dataTable($query)
    {
        return datatables()
            ->eloquent($query)
            ->editColumn('success', fn($model) => ($model->success) ? 'yes' : 'no')
            ->editColumn('user', function ($model) {
                return $model->user->full_name;
            });
    }

    /**
     * Get query source of dataTable.
     *
     * @param  \App\Models\Admin\AuthenticationLog  $model
     * @return \Illuminate\Database\Eloquent\Builder
     */
    public function query(AuthenticationLog $model)
    {
        return $model->newQuery();
    }

    /**
     * Optional method if you want to use html builder.
     *
     * @return \Yajra\DataTables\Html\Builder
     */
    public function html()
    {
        return $this->builder()
            ->setTableId('admin-authenticationlog-table')
            ->columns($this->getColumns())
            ->buttons(["csv", "excel", "pdf", "print"])
            ->minifiedAjax()
            ->dom('Bfrtlip')
            ->orderBy(1, 'asc');
    }

    /**
     * Get columns.
     *
     * @return array
     */
    protected function getColumns()
    {
        return [
            Column::make('id'),
            Column::make('user', 'user_id'),
            Column::make('success'),
            Column::make('ip'),
            Column::make('agent'),
            Column::make('created_at')
                ->exportable(false)
                ->printable(false)
                ->addClass('text-center'),
        ];
    }

    /**
     * Get filename for export.
     *
     * @return string
     */
    protected function filename()
    {
        return 'Admin-AuthenticationLog_'.date('YmdHis');
    }
}
