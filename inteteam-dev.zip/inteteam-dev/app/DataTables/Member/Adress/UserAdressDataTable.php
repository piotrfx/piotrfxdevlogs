<?php

namespace App\DataTables\Member\Adress;

use App\Models\UserDeliveryAddress;
use Yajra\DataTables\Html\Button;
use Yajra\DataTables\Html\Column;
use Yajra\DataTables\Services\DataTable;
use Yajra\DataTables\Html\Editor\Fields;
use Yajra\DataTables\Html\Editor\Editor;

class UserAdressDataTable extends DataTable
{
    /**
     * Build DataTable class.
     *
     * @param mixed $query Results from query() method.
     * @return \Yajra\DataTables\DataTableAbstract
     */
    public function dataTable($query)
    {
        return datatables()
        ->eloquent($query)
        ->editColumn('is_default',function($model){
            return ($model->is_default) ? 'YEs': 'No';
        }) 
        ->addColumn('action', function(UserDeliveryAddress $model){
        return view('member.profile.delivery_address.actions',compact('model'));
        });
    }

    /**
     * Get query source of dataTable.
     *
     * @param \App\Models\UserDeliveryAddress $model
     * @return \Illuminate\Database\Eloquent\Builder
     */
    public function query(UserDeliveryAddress $model)
    {
        $model = UserDeliveryAddress::where('user_id',auth()->id());
    
        return $model->newQuery();
        //tdatatables nie jest odpalone 

    }

    /**
     * Optional method if you want to use html builder.
     *
     * @return \Yajra\DataTables\Html\Builder
     */
    public function html()
    {
        return $this->builder()
                    ->setTableId('member-adress-useradress-table')
                    ->columns($this->getColumns())
                    ->buttons(["csv", "excel", "pdf", "print"])
                    ->minifiedAjax()
                    ->dom('Bfrtlip')
                    ->orderBy(1,'asc');
    }

    /**
     * Get columns.
     *
     * @return array
     */
    protected function getColumns()
    {
        return [
            Column::make('id'),
            Column::make('name'),
            Column::make('address_line_1'),
            Column::make('postcode'),
            Column::make('city'),
            Column::make('instruction'),
            Column::make('place_id'),
            Column::make('created_at'),
            Column::computed('action')
                ->exportable(false)
                ->printable(false)
                ->addClass('text-center'),
        ];
    }

    /**
     * Get filename for export.
     *
     * @return string
     */
    protected function filename()
    {
        return 'Member\Adress\UserAdress_' . date('YmdHis');
    }
}
