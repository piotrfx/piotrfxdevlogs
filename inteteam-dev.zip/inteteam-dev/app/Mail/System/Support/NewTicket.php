<?php

namespace App\Mail\System\Support;

use Illuminate\Mail\Mailable;
use Illuminate\Support\Facades\URL;

class NewTicket extends Mailable
{
    public $ticket;

    /**
     * NewTicket constructor.
     * @param $ticket
     */
    public function __construct($ticket)
    {
        $this->ticket = $ticket;
    }

    public function build()
    {
        $data = [
            'url'       => URL::route('admin.support.ticket.show',$this->ticket),
            'ticket_id' => $this->ticket->ticket_id
        ];
        return $this->subject('New Ticket - '.$this->ticket->ticket_id)
            ->markdown('emails.system.support.new-ticket')
            ->with('data', $data);
    }
}
