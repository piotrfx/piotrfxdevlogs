<?php

namespace App\Mail\System\Support;

use Illuminate\Mail\Mailable;
use URL;

class AssignAgent extends Mailable
{
    public $ticket;

    /**
     * AssignAgent constructor.
     * @param $ticket
     */
    public function __construct($ticket)
    {
        //
        $this->ticket = $ticket;
    }

    public function build()
    {
        $data = [
            'full_name' => $this->ticket->agent->full_name,
            'user_name' => $this->ticket->creator->full_name,
            'priority'  => $this->ticket->priority->name,
            'url'       => URL::route('admin.support.ticket.show', $this->ticket->id),
        ];
        return $this
            ->subject('Assign to new ticket')
            ->with('data', $data)
            ->markdown('emails.system.support.assign-agent');
    }
}
