<?php

namespace App\Mail\User\Member;

use App\Models\MemberInvite;
use Illuminate\Mail\Mailable;

class Invite extends Mailable
{
    public $user;
    private MemberInvite $invite;

    public function __construct(MemberInvite $invite, $user)
    {

        $this->invite = $invite;
        $this->user = $user;
    }

    public function build()
    {
        $data = [
            'first_name' => $this->invite->first_name,
            'last_name'  => $this->invite->last_name,
            'inviting'   => $this->user->full_name,
            'url'        => route('register', ['id' => $this->invite->id, 'hash' => $this->invite->hash])
        ];
        return $this
            ->subject('Invitation to Club')
            ->with('data', $data)
            ->markdown('user.member.invite-user');
    }
}
