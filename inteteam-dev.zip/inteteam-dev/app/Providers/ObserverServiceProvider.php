<?php

namespace App\Providers;

use App\Models\Category;
use App\Models\FaqCategory;
use App\Models\MemberInvite;
use App\Models\Page;
use App\Models\Post;
use App\Models\Product;
use App\Models\ProductCategory;
use App\Models\ProductType;
use App\Models\Supplier;
use App\Models\SupportCategory;
use App\Models\SupportTicket;
use App\Models\SupportTicketMessage;
use App\Models\Tag;
use App\Observers\CategoryObserver;
use App\Observers\FaqCategoryObserver;
use App\Observers\PageObserver;
use App\Observers\PostObserver;
use App\Observers\ProductCategoryObserver;
use App\Observers\ProductObserver;
use App\Observers\ProductTypeObserver;
use App\Observers\SupplierObserver;
use App\Observers\SupportCategoryObserver;
use App\Observers\SupportTicketObserver;
use App\Observers\TagObserver;
use App\Observers\User\Member\InviteObserver;
use App\Observers\User\Member\SupportTicketMessageObserver;
use Illuminate\Support\ServiceProvider;

class ObserverServiceProvider extends ServiceProvider
{
    /**
     * Register services.
     */
    public function register()
    {
        //
    }

    /**
     * Bootstrap services.
     */
    public function boot()
    {
        Category::observe(CategoryObserver::class);
        Tag::observe(TagObserver::class);
        Post::observe(PostObserver::class);
        ProductCategory::observe(ProductCategoryObserver::class);
        Product::observe(ProductObserver::class);
        Supplier::observe(SupplierObserver::class);
        Page::observe(PageObserver::class);
        FaqCategory::observe(FaqCategoryObserver::class);
        SupportTicket::observe(SupportTicketObserver::class);
        MemberInvite::observe(InviteObserver::class);
        SupportTicketMessage::observe(SupportTicketMessageObserver::class);
        SupportCategory::observe(SupportCategoryObserver::class);
        ProductType::observe(ProductTypeObserver::class);
    }
}
