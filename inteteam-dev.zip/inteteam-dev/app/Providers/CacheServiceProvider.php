<?php

namespace App\Providers;

use App\Models\Category;
use App\Models\Post;
use App\Models\Tag;
use App\Models\ProductCategory;
use Cache;
use DB;
use Illuminate\Support\ServiceProvider;
use View;

class CacheServiceProvider extends ServiceProvider
{
    /**
     * Register services.
     *
     * @return void
     */
    public function register()
    {
        //
    }

    /**
     * Bootstrap services.
     *
     * @return void
     */
    public function boot()
    {
        View::composer('front.blog.partials.widgets._tags', function ($view) {
            $view->with('cacheTags', Cache::remember('cacheTags', config('cache.expire'), function () {
                return Tag::select('slug', 'name')
                    ->where('status', 1)
                    ->get();
            }));
        });
        View::composer('front.blog.partials.widgets._category', function ($view) {
            $view->with('cacheCategory', Cache::remember('cacheCategory', config('cache.expire'), function () {
                return Category::select('name', 'slug')
                    ->where('status', 1)
                    ->get();
            }));
        });
        View::composer('front.blog.partials.widgets._archives', function ($view) {
            $view->with('cacheArchive', Cache::remember('cacheArchive', config('cache.expire'), function () {
                return DB::table('posts')->select(DB::raw('year(created_at) year, monthname(created_at) month, count(*) published'))
                    ->groupBy('year', 'month')
                    ->orderByRaw('min(created_at) desc')
                    ->where('status', 1)
                    ->get();
            }));
        });
        View::composer('front.blog.partials.widgets._recent_posts', function ($view) {
            $view->with('cacheRecent_post', Cache::remember('cacheRecent_post', config('cache.expire'), function () {
                return Post::with('creator')
                    ->select(['title', 'image_path', 'user_id', 'created_at','slug'])
                    ->where('status',1)
                    ->latest()
                    ->take(5)
                    ->get();
            }));
        });
        View::composer('shop.dashboard.layout.partials.widgets._categories', function ($view) {
            $view->with('cacheProductCategory', Cache::remember('cacheProductCategory', config('cache.expire'), function () {
                return ProductCategory::withCount('products')
                ->where('status', 1)
                ->get();
            }));
        });
        View::composer('shop.dashboard.layout.partials.widgets._supplier', function ($view) {
            $view->with('cacheSupplier', Cache::remember('cacheSupplier', config('cache.expire'), function () {
                return Supplier::select('name','slug')
                ->orderBy('name','ASC')
                ->get();
            }));
        });
    }
}
