<?php

namespace App\Providers;

use Illuminate\Cache\RateLimiting\Limit;
use Illuminate\Foundation\Support\Providers\RouteServiceProvider as ServiceProvider;
use Illuminate\Http\Request;
use Illuminate\Support\Facades\RateLimiter;
use Illuminate\Support\Facades\Route;

class RouteServiceProvider extends ServiceProvider
{
    /**
     * The path to the "home" route for your application.
     *
     * This is used by Laravel authentication to redirect users after login.
     *
     * @var string
     */
    public const HOME = '/';
    public const ROOT = '/root';
    public const ADMIN = '/admin';
    public const PARTNER = '/partner';
    public const LEAD = '/lead';
    public const PAYROLL = '/payroll';
    public const MODERATOR = '/moderator';
    public const MEMBER = '/member';
    public const SUPPORT = '/support';

    /**
     * The controller namespace for the application.
     *
     * When present, controller route declarations will automatically be prefixed with this namespace.
     *
     * @var string|null
     */
    protected $namespace = 'App\\Http\\Controllers';

    /**
     * Define your route model bindings, pattern filters, etc.
     *
     * @return void
     */
    public function boot()
    {
        $this->configureRateLimiting();

        $this->routes(function () {
            Route::prefix('api')
                ->middleware('api')
                ->namespace($this->namespace)
                ->group(base_path('routes/api.php'));

            Route::middleware('web')
                ->namespace($this->namespace)
                ->group(base_path('routes/web.php'));

            Route::middleware(['web','auth','verified','role:Admin|Support'])
                ->prefix('admin')
                ->namespace($this->namespace.'\Admins')
                ->name('admin.')
                ->group(base_path('routes/custom/admin.php'));

            Route::middleware('web')
                ->namespace($this->namespace.'\Shop')
                ->name('shop.')
                ->prefix('shop')
                ->group(base_path('routes/custom/shop.php'));

            Route::middleware(['web','auth','verified'])
                ->namespace($this->namespace.'\Leads')
                ->name('lead.')
                ->prefix('lead')
                ->group(base_path('routes/custom/lead.php'));

            Route::middleware(['web','auth','verified'])
                ->namespace($this->namespace.'\Moderators')
                ->name('moderator.')
                ->prefix('moderator')
                ->group(base_path('routes/custom/moderator.php'));

            Route::middleware(['web','auth','verified'])
                ->namespace($this->namespace.'\Partners')
                ->name('partner.')
                ->prefix('partner')
                ->group(base_path('routes/custom/partner.php'));

            Route::middleware(['web','auth','verified'])
                ->namespace($this->namespace.'\Members')
                ->name('member.')
                ->prefix('member')
                ->group(base_path('routes/custom/member.php'));

            Route::middleware(['web','auth','verified','role:Payroll'])
                ->namespace($this->namespace.'\Payroll')
                ->name('payroll')
                ->prefix('payroll')
                ->group(base_path('routes/custom/payroll.php'));

            Route::middleware(['web','auth','verified','role:User'])
                ->namespace($this->namespace.'\Users')
                ->name('user.')
                ->prefix('user')
                ->group(base_path('routes/custom/user.php'));
            Route::middleware('web')
                ->namespace($this->namespace.'\Front')
                ->name('front.')
                ->group(base_path('routes/custom/front.php'));

        });
    }

    /**
     * Configure the rate limiters for the application.
     *
     * @return void
     */
    protected function configureRateLimiting()
    {
        RateLimiter::for('api', function (Request $request) {
            return Limit::perMinute(60)->by(optional($request->user())->id ?: $request->ip());
        });
    }
}
