<?php

namespace App\Http\Requests\Admin\UserManagement;

use Illuminate\Foundation\Http\FormRequest;
use Illuminate\Validation\Rule;

class PermissionRequest extends FormRequest
{
    public function rules()
    {
        return [
            'name'  => [
                'required',
                'min:3',
                'max:190',
                Rule::unique('roles', 'name')->ignore($this->permission)
            ],
            'roles' => [
                'required',
                'array',
                'min:1'
            ]
        ];
    }

    public function messages()
    {
        return [
            'roles' => [
                'required' => 'Roles Is required'
            ]
        ];
    }

    public function authorize()
    {
        return true;
    }
}
