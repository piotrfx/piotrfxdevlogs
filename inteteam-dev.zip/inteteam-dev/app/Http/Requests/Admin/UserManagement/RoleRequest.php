<?php

namespace App\Http\Requests\Admin\UserManagement;

use Illuminate\Foundation\Http\FormRequest;
use Illuminate\Validation\Rule;

class RoleRequest extends FormRequest
{
    public function rules()
    {
        return [
            'name' => [
                'required',
                'min:3',
                'max:190',
                Rule::unique('roles', 'name')->ignore($this->role)
            ]
        ];
    }

    public function authorize()
    {
        return true;
    }
}
