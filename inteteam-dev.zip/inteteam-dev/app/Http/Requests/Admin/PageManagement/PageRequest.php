<?php

namespace App\Http\Requests\Admin\PageManagement;

use Illuminate\Foundation\Http\FormRequest;
use Illuminate\Validation\Rule;

class PageRequest extends FormRequest
{
    public function rules()
    {
        return [
            'title' => [
                'required',
                'min:5',
                'max:190',
                Rule::unique('pages', 'title')->ignore($this->page)
            ],
            'body'  => [
                'required',
                'max:5000'
            ]
        ];
    }

    public function authorize()
    {
        return true;
    }
}
