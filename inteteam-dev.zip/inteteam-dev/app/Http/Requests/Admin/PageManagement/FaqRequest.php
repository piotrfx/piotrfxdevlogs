<?php

namespace App\Http\Requests\Admin\PageManagement;

use Illuminate\Foundation\Http\FormRequest;

class FaqRequest extends FormRequest
{
    public function rules()
    {
        return [
            'category'=>[
                'required',
                'numeric'
            ],
            'question'=>[
                'required',
                'min:5',
                'max:1000',
            ],
            'answer'=>[
                'required',
                'min:20',
                'max:10000'
            ]
        ];
    }

    public function authorize()
    {
        return true;
    }
}
