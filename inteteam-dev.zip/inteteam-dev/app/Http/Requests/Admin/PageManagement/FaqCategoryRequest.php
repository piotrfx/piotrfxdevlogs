<?php

namespace App\Http\Requests\Admin\PageManagement;

use Illuminate\Foundation\Http\FormRequest;
use Illuminate\Validation\Rule;

class FaqCategoryRequest extends FormRequest
{
    public function rules()
    {
        return [
            'name' => [
                'required',
                'string',
                'min:3',
                'max:200',
                Rule::unique('faq_categories', 'name')->ignore($this->faq_category)
            ]
        ];
    }

    public function authorize()
    {
        return true;
    }
}
