<?php

namespace App\Http\Requests\Admin\Payment;

use Illuminate\Foundation\Http\FormRequest;
use Illuminate\Validation\Rule;

class PlanRequest extends FormRequest
{
    public function rules()
    {
        return [
           'name'=>[
               'required',
               'min:3',
               'max:190',
               Rule::unique('plans','name')->ignore($this->plan)
           ],
            'price'=>[
                'required',
                'numeric'
            ],
            'stripe_plan_id' => [
                'required'
            ],
            'description'=>[
                'required',
                'min:10',
                'max:5000'
            ]
        ];
    }

    public function authorize()
    {
        return true;
    }
}
