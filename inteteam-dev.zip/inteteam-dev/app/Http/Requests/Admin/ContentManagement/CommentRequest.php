<?php

namespace App\Http\Requests\Admin\ContentManagement;

use Illuminate\Foundation\Http\FormRequest;

class CommentRequest extends FormRequest
{
    public function rules()
    {
        return [
            'creator' => [
                'required',
                'numeric'
            ],
            'post' => [
                'required',
                'numeric'
            ],
            'body'    => [
                'required',
                'max:5000'
            ]
        ];
    }

    public function authorize()
    {
        return true;
    }
}
