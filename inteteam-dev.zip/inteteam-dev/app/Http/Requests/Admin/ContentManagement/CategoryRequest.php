<?php

namespace App\Http\Requests\Admin\ContentManagement;

use Illuminate\Foundation\Http\FormRequest;
use Illuminate\Validation\Rule;

class CategoryRequest extends FormRequest
{
    public function rules()
    {
        return [
            'name' => [
                'required',
                'min:3',
                'max:190',
                Rule::unique('categories', 'name')->ignore($this->category)
            ]
        ];
    }

    public function authorize()
    {
        return true;
    }
}
