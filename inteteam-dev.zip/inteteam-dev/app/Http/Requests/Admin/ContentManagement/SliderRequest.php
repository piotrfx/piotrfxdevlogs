<?php

namespace App\Http\Requests\Admin\ContentManagement;

use Illuminate\Foundation\Http\FormRequest;
use Illuminate\Validation\Rule;

class SliderRequest extends FormRequest
{
    public function rules()
    {
        return [
            'name'  => ['required', 'max:200', Rule::unique('posts', 'title')->ignore($this->slider)],
            'body'  => ['required', 'max:400'],
            'image' => ['required', 'image', 'max:4096']
        ];
    }

    public function authorize()
    {
        return true;
    }
}
