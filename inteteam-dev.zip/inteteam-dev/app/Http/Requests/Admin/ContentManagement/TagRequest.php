<?php

namespace App\Http\Requests\Admin\ContentManagement;

use Illuminate\Foundation\Http\FormRequest;
use Illuminate\Validation\Rule;

class TagRequest extends FormRequest
{
    public function rules()
    {
        return [
            'name' => [
                'required',
                'min:2',
                'max:200',
                Rule::unique('tags', 'name')->ignore($this->tag)
            ]
        ];
    }

    public function authorize()
    {
        return true;
    }
}
