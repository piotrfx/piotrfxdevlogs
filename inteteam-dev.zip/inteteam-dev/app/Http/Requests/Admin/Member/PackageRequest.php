<?php

namespace App\Http\Requests\Admin\Member;

use Illuminate\Foundation\Http\FormRequest;
use Illuminate\Validation\Rule;

class PackageRequest extends FormRequest
{
    public function rules()
    {
        return [
            'name'           => [
                'required',
                'min:3',
                'max:100',
                Rule::unique('membership_packages', 'name')->ignore($this->package)
            ],
            'price'          => [
                'required',
                'min:1',
                'numeric'
            ],
            'stripe_plan_id' => [
                'required',
                'string'
            ],
            'description'    => [
                'required',
                'min:10',
                'max:1000'
            ],
        ];
    }

    public function authorize()
    {
        return true;
    }
}
