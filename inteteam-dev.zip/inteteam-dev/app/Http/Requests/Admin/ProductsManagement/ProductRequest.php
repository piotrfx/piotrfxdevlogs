<?php

namespace App\Http\Requests\Admin\ProductsManagement;

use Illuminate\Foundation\Http\FormRequest;
use Illuminate\Validation\Rule;

class ProductRequest extends FormRequest
{
    public function rules()
    {
        return [
            'name'         => [
                'required',
                'min:3',
                'max:150',
                Rule::unique('products', 'name')->ignore($this->product)
            ],
            'category'     => [
                'required',
                'integer'
            ],
            'image'        => [
                'required',
                'max:4096',
                'image'
            ],
            'price'        => [
                'required',
                'regex:/^\d+(\.\d{1,2})?$/'
            ],
            'sku'          => [
                'required',
                'alpha_num'
            ],
            'qty'          => [
                'numeric',
                'gte:0'
            ],
            'short_description'  => [
                'required',
                'max:150'
            ],
            'long_description' => [
                'required',
                'min:20',
                'max:1000'
            ],
            'content'      => [
                'required'
            ],
            'supplier'     => [
                'required',
                'numeric'
            ],
            'available_at' => [
                'required',
                'date_format:Y-m-d',
                'after_or_equal:'.now()->addDay()->format('Y-d-m')
            ],
            'images.*'     => [
                'sometimes',
                'image',
                'max:4096'
            ],
            'product_type' => [
                'required'
            ],
            'expiry_date' => [
                'date_format:Y-m-d'
            ]

        ];
    }

    public function authorize()
    {
        return true;
    }
}
