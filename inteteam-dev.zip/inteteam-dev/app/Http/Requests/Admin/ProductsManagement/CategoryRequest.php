<?php

namespace App\Http\Requests\Admin\ProductsManagement;

use Illuminate\Foundation\Http\FormRequest;
use Illuminate\Validation\Rule;

class CategoryRequest extends FormRequest
{
    public function rules()
    {
        return [
            'title'=>[
                'min:5',
                'max:200',
                'required',
                Rule::unique('product_categories','title')->ignore($this->category)
            ],
            'description'=>[
                'required',
                'min:10',
                'max:350'
            ],
            'parent'=>[
                'numeric'
            ],
            'sort'=>[
                'numeric',
                'min:0'
            ],
            'image'    => [
                'required',
                'image',
                'max:4096'
            ],
        ];
    }

    public function authorize()
    {
        return true;
    }
}
