<?php

namespace App\Http\Requests\Admin\ProductsManagement;

use Illuminate\Foundation\Http\FormRequest;
use Illuminate\Validation\Rule;

class SupplierRequest extends FormRequest
{
    public function rules()
    {
        return [
            'name' => [
                'required',
                'max:200',
                'min:3',
                Rule::unique('suppliers', 'name')->ignore($this->supplier)
            ],
            'description' => [
                'required',
                'max:5000',
                'min:10'
            ],
            'first_line_address' => [
                'required',
                'max:200'
            ],
            'second_line_address' => [
                'max:200'
            ],
            'post_code' => [
                'required',
                'max:200',
            ],
            'town' => [
                'required',
                'max:200',
            ],
            'contact_phone' => [
                'required',
                'max:200',
            ],
            'contact_email' => [
                'required',
                'max:200',
            ],
            'vat_no' => [
                'max:200'
            ],
            'form_of_payment' => [
                'max:200'
            ],
            'bank_name' => [
                'required',
            ],
            'sort_code' => [
                'required',
                'digits:6'
            ],
            'account_number' => [
                'required',
                'digits:8'
            ],
            'registration_number' => [
                'required'
            ]
        ];
    }

    public function authorize()
    {
        return true;
    }
}
