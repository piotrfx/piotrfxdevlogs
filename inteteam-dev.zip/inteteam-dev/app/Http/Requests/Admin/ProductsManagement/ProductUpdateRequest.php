<?php

namespace App\Http\Requests\Admin\ProductsManagement;

use Illuminate\Foundation\Http\FormRequest;
use Illuminate\Validation\Rule;

class ProductUpdateRequest extends FormRequest
{
    public function rules()
    {
        return [
            'name'         => [
                'required',
                'min:3',
                'max:200',
                Rule::unique('products', 'name')->ignore($this->product)
            ],
            'category'     => [
                'required',
                'integer'
            ],
            'image'        => [
                'nullable',
                'max:4096',
                'image'
            ],
            'price'        => [
                'required',
                'regex:/^\d+(\.\d{1,2})?$/'
            ],
            'sku'          => [
                'required',
                'alpha_num'
            ],
            'qty'          => [
                'required',
                'numeric',
                'gte:0'
            ],
            'description'  => [
                'required',
                'min:20',
                'max:5000'
            ],
            'content'      => [
                'required'
            ],
            'supplier'     => [
                'required',
                'numeric'
            ],
            'available_at' => [
                'required',
                'date_format:d/m/Y',
                'after_or_equal:'.date('d/m/Y')
            ],
            'images.*'     => [
                'sometimes',
                'image',
                'max:4096'
            ]

        ];
    }

    public function authorize()
    {
        return true;
    }
}
