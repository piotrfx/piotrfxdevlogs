<?php

namespace App\Http\Requests\Admin\Support;

use Illuminate\Foundation\Http\FormRequest;
use Illuminate\Validation\Rule;

class CategoryRequest extends FormRequest
{
    public function rules()
    {
        return [
            'name' => [
                'required',
                'min:5',
                'max:100',
                Rule::unique('support_categories', 'name')->ignore($this->category)
            ]
        ];
    }

    public function authorize()
    {
        return true;
    }
}
