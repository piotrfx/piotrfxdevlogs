<?php

namespace App\Http\Requests\Admin\Support;

use Illuminate\Foundation\Http\FormRequest;
use Illuminate\Validation\Rule;

class PriorityRequest extends FormRequest
{
    public function rules(): array
    {
        return [
           'name'=>[
               'required',
               'min:3',
               'max:50',
               Rule::unique('support_priorities','name')->ignore($this->priority)
           ]
        ];
    }

    public function authorize(): bool
    {
        return true;
    }
}
