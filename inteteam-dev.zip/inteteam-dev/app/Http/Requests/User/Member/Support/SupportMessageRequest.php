<?php

namespace App\Http\Requests\User\Member\Support;

use Illuminate\Foundation\Http\FormRequest;

class SupportMessageRequest extends FormRequest
{
    public function rules()
    {
        return [
            'message' => [
                'required',
                'min:5',
                'max:1000'
            ]
        ];
    }

    public function authorize()
    {
        return true;
    }
}
