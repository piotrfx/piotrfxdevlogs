<?php

namespace App\Http\Requests\User\Member\Support;

use Illuminate\Foundation\Http\FormRequest;

class NewTicketRequest extends FormRequest
{
    public function rules()
    {
        return [
            'title'    => [
                'required',
                'min:5',
                'max:200'
            ],
            'message'  => [
                'required',
                'min:10',
                'max:1000'
            ],
            'category' => [
                'required',
                'exists:support_categories,id'
            ],
            'priority' => [
                'required',
                'exists:support_priorities,id'
            ]
        ];
    }

    public function authorize()
    {
        return true;
    }
}
