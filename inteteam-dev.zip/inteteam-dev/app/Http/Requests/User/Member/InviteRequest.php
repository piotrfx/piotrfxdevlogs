<?php

namespace App\Http\Requests\User\Member;

use Illuminate\Foundation\Http\FormRequest;

class InviteRequest extends FormRequest
{
    public function rules()
    {
        return [
            'first_name' => ['required', 'string', 'min:3', 'max:255'],
            'last_name'  => ['required', 'string', 'min:3', 'max:255'],
            'email'      => ['required', 'string', 'email', 'max:255', 'unique:member_invites'],
        ];
    }

    public function authorize()
    {
        return true;
    }
}
