<?php

namespace App\Http\Requests\User\Profile;

use Illuminate\Foundation\Http\FormRequest;

class DeliveryAddressRequest extends FormRequest
{
    public function rules()
    {
        return [
            'address_line_1' =>
                ['required', 'min:5', 'max:400'],
            'address_line_2' =>
                ['nullable', 'min:5', 'max:400'],
            'postcode'       => ['required', 'max:10'],
            'city'           => ['required', 'max:400'],
            'country'        => ['required'],
            'instruction'    => ['nullable', 'max:400']
        ];
    }

    public function authorize()
    {
        return true;
    }
}
