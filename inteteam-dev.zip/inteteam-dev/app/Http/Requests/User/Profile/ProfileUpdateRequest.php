<?php

namespace App\Http\Requests\User\Profile;

use Illuminate\Foundation\Http\FormRequest;
use Illuminate\Validation\Rule;

class ProfileUpdateRequest extends FormRequest
{
    public function rules()
    {

        return [
            'first_name' => [
                'required',
                'string',
                'min:3',
                'max:255'
            ],
            'last_name'  => [
                'required',
                'string',
                'min:3',
                'max:255'
            ],
            'user_name'  => [
                'required',
                'string',
                'min:3',
                'max:255',
                Rule::unique('users','user_name')->ignore($this->getId())
                ],
            'email'      => [
                'required',
                'string',
                'email',
                'max:255',
                Rule::unique('users','email')->ignore($this->getId())
            ],
            'password'   => [
                'nullable',
                'string',
                'min:8',

            ],
            'avatar'=>[
                'nullable',
                'image',
                'max:2048'
            ],
            'phone'     => [
                'nullable',
                'phone:GB'
            ],
            'reply_address'=>[
                'nullable',
            ],
            'delivery_address'     => [
                'nullable',
            ],
            'description' =>[
                'nullable',
                'min:10',
                'max:5000'
            ],
            'personality' =>[
                'required',
                'integer'
            ]
        ];
    }

    /**
     * @return int|mixed
     */
    private function getId(): mixed
    {
        return auth()->user()->id;
    }

    public function authorize()
    {
        return true;
    }
}
