<?php

namespace App\Http\Controllers\Shop;

use App\Http\Controllers\Controller;
use Illuminate\Http\Request;
use App\Models\User;

class WalletController extends Controller
{
    public function index()
    {
        return  auth()->user()->wallet;
    }
}
