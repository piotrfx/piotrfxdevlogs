<?php

namespace App\Http\Controllers\Shop;

use App\Http\Controllers\Controller;
use App\Models\Product;

class ProductController extends Controller
{
    public function show(Product $product)
    {
        return view('shop.single_product.index')
            ->with('product', $product->load('productCategory', 'productImages', 'productType', 'productSupplier'));
        //return $product->productCategory->title;
    }
}
