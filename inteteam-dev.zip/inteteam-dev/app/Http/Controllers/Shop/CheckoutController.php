<?php

namespace App\Http\Controllers\Shop;

use App\Http\Controllers\Controller;
use Illuminate\Http\Request;
use App\Models\User;
use App\Models\Country;
use Gloudemans\Shoppingcart\Facades\Cart;

class CheckoutController extends Controller
{
    public function index()
    {
        $auth_user_load = auth()->user()->load('deliveryAddresses', 'profile');
        $card_subtotal = Cart::subtotal();
        $card_total = Cart::total();
        $pay = array(
            'user' => $auth_user_load,
            'subtotal' => $card_subtotal,
            'total' => $card_total
        );
        //return $pay;
        return view('shop.checkout.index')
        ->with('user', $auth_user_load)
        ->with('products',Cart::content())
        ->with('subtotal', $card_subtotal)
        ->with('total', $card_total);
    }
}
