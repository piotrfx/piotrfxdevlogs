<?php

namespace App\Http\Controllers;

use Gloudemans\Shoppingcart\Facades\Cart;
use Illuminate\Http\Request;
use Srmklive\PayPal\Services\ExpressCheckout;

class PayPalPaymentController extends Controller
{
    public function handlePayment()
    {
        $product = [];
        $product['items'] = [];
        $product['total'] = 0;
        $cart_content = Cart::content();
        foreach ($cart_content as $c) {
            array_push($product['items'], [
                'name'  => $c->name,
                'price' => $c->price,
                'desc'  => 'opis',
                'qty'   => $c->qty
            ]);
        }


        $product['invoice_id'] = 1;
        $product['invoice_description'] = "Order #{$product['invoice_id']} Bill";
        $product['return_url'] = route('success.payment');
        $product['cancel_url'] = route('cancel.payment');
        $product['total'] = Cart::subtotal(null,null,'');

        $paypalModule = new ExpressCheckout;

        //that is correct ?
        $res = $paypalModule->setExpressCheckout($product);
        $res = $paypalModule->setExpressCheckout($product, true);
        //that is correct ?
        return redirect($res['paypal_link']);
    }

    public function paymentCancel()
    {
        //do not kill a process;
        //update status in order as canceled and redirect to basket ?
        dd('Your payment has been declend. The payment cancelation page goes here!');
    }

    public function paymentSuccess(Request $request)
    {
        $paypalModule = new ExpressCheckout;
        $response = $paypalModule->getExpressCheckoutDetails($request->token);

        if (in_array(strtoupper($response['ACK']), ['SUCCESS', 'SUCCESSWITHWARNING'])) {
            //do not kill process
            //redirect to page with conformation of order
            //update payment status
            dd('Payment was successfull. The payment success page goes here!');
        }

        dd('Error occured!');
    }
}
