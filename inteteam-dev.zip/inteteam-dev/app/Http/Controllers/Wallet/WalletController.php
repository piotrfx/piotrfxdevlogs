<?php

namespace App\Http\Controllers\Wallet;

use App\Http\Controllers\Controller;
use Illuminate\Http\Request;
Use App\Models\Wallet;

class WalletController extends Controller
{
    //Index
    public function index()
    {   
        return '/wallet';
    }
}
