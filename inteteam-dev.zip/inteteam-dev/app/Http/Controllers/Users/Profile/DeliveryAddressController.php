<?php

namespace App\Http\Controllers\Users\Profile;

use App\Http\Controllers\Controller;
use App\Http\Requests\User\Profile\DeliveryAddressRequest;
use App\Models\Country;
use App\Models\UserDeliveryAddress;
use Illuminate\Http\Request;

class DeliveryAddressController extends Controller
{
    /**
     * Display a listing of the resource.
     *
     * @return \Illuminate\Http\Response
     */
    public function index()
    {
        return view('user.profile.delivery_address.index')
            ->with('addresses', auth()->user()->deliveryAddresses);
    }

    /**
     * Show the form for creating a new resource.
     *
     * @return \Illuminate\Http\Response
     */
    public function create()
    {
        $counties = Country::all();
        return view('user.profile.delivery_address.create')
            ->with('countries', $counties);
    }

    /**
     * Store a newly created resource in storage.
     *
     * @param  Request  $request
     * @return \Illuminate\Http\Response
     */
    public function store(DeliveryAddressRequest $request)
    {

        if ($request->get('default') ) {
            if ($address = auth()->user()->defaultDeliveryAddress()) {
                $address->update(['is_default' => false]);
            }

        }
        auth()->user()->deliveryAddresses()->create([
            'address_line_1' => $request->get('address_line_1'),
            'address_line_2' => $request->get('address_line_2'),
            'postcode'       => $request->get('postcode'),
            'city'           => $request->get('city'),
            'country_id'     => $request->get('country'),
            'instruction'    => $request->get('instruction'),
            'is_default'     => (bool) $request->get('default')
        ]);
        return redirect()->route('user.profile.delivery-address.index');
    }

    /**
     * Display the specified resource.
     *
     * @param  UserDeliveryAddress  $deliveryAddress
     * @return \Illuminate\Http\Response
     */
    public function show(UserDeliveryAddress $deliveryAddress)
    {
        return $deliveryAddress;
    }

    /**
     * Show the form for editing the specified resource.
     *
     * @param  UserDeliveryAddress  $deliveryAddress
     * @return \Illuminate\Http\Response
     */
    public function edit(UserDeliveryAddress $deliveryAddress)
    {
        $counties = Country::all();
        return view('user.profile.delivery_address.edit')
            ->with('countries', $counties)
            ->with('address', $deliveryAddress);
    }

    /**
     * Update the specified resource in storage.
     *
     * @param  Request  $request
     * @param  UserDeliveryAddress  $deliveryAddress
     * @return \Illuminate\Http\Response
     */
    public function update(Request $request, UserDeliveryAddress $deliveryAddress)
    {
        if ($request->get('default')) {
            auth()->user()->defaultDeliveryAddress()->update(['is_default' => false]);
        }
        $deliveryAddress->update([
            'address_line_1' => $request->get('address_line_1'),
            'address_line_2' => $request->get('address_line_2'),
            'postcode'       => $request->get('postcode'),
            'city'           => $request->get('city'),
            'country_id'     => $request->get('country'),
            'instruction'    => $request->get('instruction'),
            'is_default'     => (bool) $request->get('default')
        ]);
        return redirect()->route('user.profile.delivery-address.index');
    }

    /**
     * Remove the specified resource from storage.
     *
     * @param  UserDeliveryAddress  $deliveryAddress
     * @return \Illuminate\Http\Response
     */
    public function destroy(UserDeliveryAddress $deliveryAddress)
    {
        //
    }
}
