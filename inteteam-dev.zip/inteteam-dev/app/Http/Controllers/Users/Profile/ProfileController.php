<?php

namespace App\Http\Controllers\Users\Profile;

use App\Http\Controllers\Controller;
use App\Http\Requests\User\Profile\ProfileUpdateRequest;

class ProfileController extends Controller
{
    public function show()
    {
        //display user profile
        return view('user.profile.account_details.index')->with('profile', auth()->user()->load('profile'));
    }

    public function edit()
    {
        return view('user.profile.index')
            ->with('user', auth()->user()->load('profile'));
    }

    public function update(ProfileUpdateRequest $request)
    {

        $update = [
            'first_name' => $request->get('first_name'),
            'last_name'  => $request->get('last_name'),
            'email'      => $request->get('email')
        ];
        if ($request->get('password') && !\Hash::check($request->get('password'), auth()->user()->password)) {
            $update['password'] = \Hash::make($request->get('password'));
        }
        auth()->user()->update($update);
        if ($request->get('phone') != auth()->user()->profile->phone) {
            auth()->user()->profile->update([
                'phone' => $request->get('phone')
            ]);
        }
        if ($request->get('description') != auth()->user()->profile->description) {
            auth()->user()->profile->update([
                'description' => $request->get('description')
            ]);
        }
        if ($request->hasFile('avatar')) {
            \Storage::delete(auth()->user()->profile->avatar);
            auth()->user()->profile->update([
                'avatar' => \Storage::put('/media/images/users/avatars', $request->file('avatar'))
            ]);
        }


        return redirect()->route('user.profile.show')
            ->with('message', 'Profile has been updated');
    }
}
