<?php

namespace App\Http\Controllers\Users\Member\Chat;

use App\Http\Controllers\Controller;

class IndexController extends Controller
{
    public function index()
    {
        return view('user.member.chat.index');
    }
}
