<?php

namespace App\Http\Controllers\Users\Member\Chat;

use App\Events\User\Members\Chat\NewMessage;
use App\Http\Controllers\Controller;
use App\Models\ChatMessage;
use Illuminate\Http\JsonResponse;
use Illuminate\Http\Request;

class ConversationController extends Controller
{
    /** Get all messages by logged in user
     * @param $id
     * @return JsonResponse
     */
    public function getMessagesFor($id)
    {
        //allow only ajax requests
        if (request()->ajax()) {
            // mark all messages with the selected contact as read
            ChatMessage::where([
                ['from', '=', $id],
                ['to', '=', auth()->id()]
            ])->update(['read' => true]);

            // get all messages between the authenticated user and the selected user
            $messages = ChatMessage::where(function ($q) use ($id) {
                $q->where([
                    ['from', '=', auth()->id()],
                    ['to', '=', $id]
                ]);
            })->orWhere(function ($q) use ($id) {
                $q->where([
                    ['from', '=', $id],
                    ['to', '=', auth()->id()]
                ]);
            })->orderBy('id', 'ASC')
                ->get();
            //send response
            return response()->json($messages);
        }
        //send 403 response
        return response()->json('Access Denied', 403);
    }

    /** Send message
     * @param  Request  $request
     * @return JsonResponse
     */
    public function send(Request $request)
    {
        //allow only ajax requests
        if ($request->ajax()) {

            //store message in db
            $message = ChatMessage::create([
                'from' => auth()->id(),
                'to'   => $request->get('contact_id'),
                'text' => $request->get('text')
            ]);
            //broadcast message
            broadcast(new NewMessage($message));
            //send message as response.
            return response()->json($message);
        }
        //send 403 response
        return response()->json('Access Denied', 403);
    }

    /** Set message as read when user has open chat.
     * @param  Request  $request
     *
     */
    public function markAsReadCurrentChat(Request $request)
    {
        ChatMessage::where([
            ['from', '=', $request->get('message_from')],
            ['to', '=', auth()->id()]
        ])->update(['read' => true]);
    }
}
