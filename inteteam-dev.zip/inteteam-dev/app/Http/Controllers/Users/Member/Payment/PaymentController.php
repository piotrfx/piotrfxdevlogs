<?php

namespace App\Http\Controllers\Users\Member\Payment;

use App\DataTables\User\Member\Billing\PaymentDataTable;
use App\Http\Controllers\Controller;
use App\Models\Payment;

class PaymentController extends Controller
{
    /**
     * Display a listing of the resource.
     *
     * @return \Illuminate\Contracts\Foundation\Application|\Illuminate\Contracts\View\Factory|\Illuminate\View\View|void
     */
    public function index(PaymentDataTable $dataTable)
    {
        return $dataTable->render('user.member.billing.payment.index');

    }

    public function download($id)
    {
        $payment = Payment::where('user_id', auth()->id())->where('uuid', $id)->firstOrFail();
        $filename = 'storage/invoices/'.$payment->id.'.pdf';

        if (!file_exists($filename)) {
            abort(404);
        }
        return response()->download($filename);
    }
}
