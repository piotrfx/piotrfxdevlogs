<?php

namespace App\Http\Controllers\Users\Member\Payment;

use App\Http\Controllers\Controller;
use App\Models\Plan;
use Illuminate\Http\Request;

class BillingController extends Controller
{
    /**
     * @param  Request  $request
     * @return \Illuminate\Contracts\Foundation\Application|\Illuminate\Contracts\View\Factory|\Illuminate\View\View|void
     */
    public function index(Request $request)
    {
        $plans = Plan::all();
        $currentPlan = auth()->user()->subscription('default') ?? null;
        $paymentMethods = auth()->user()->paymentMethods();
        $defaultPaymentMethod = auth()->user()->defaultPaymentMethod();
        return view(
            'user.member.billing.index',
            compact('plans', 'currentPlan', 'paymentMethods', 'defaultPaymentMethod')
        );
    }

    public function cancel()
    {
        auth()->user()->subscription('default')->cancel();
        return redirect()->route('business.subscription.billing');
    }

    public function resume()
    {
        auth()->user()->subscription('default')->resume();
        return redirect()->route('business.subscription.billing');
    }
}
