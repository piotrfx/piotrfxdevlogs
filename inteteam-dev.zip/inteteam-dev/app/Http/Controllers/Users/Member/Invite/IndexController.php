<?php

namespace App\Http\Controllers\Users\Member\Invite;

use App\Http\Controllers\Controller;
use App\Http\Requests\User\Member\InviteRequest;
use App\Models\MemberInvite;

class IndexController extends Controller
{
    public function index()
    {
        return view('user.member.invite.index');
    }

    public function store(InviteRequest $request)
    {
        MemberInvite::create([
            'first_name' => $request->get('first_name'),
            'last_name'  => $request->get('last_name'),
            'email'      => $request->get('email'),
        ]);

        return 'ok';
    }
}
