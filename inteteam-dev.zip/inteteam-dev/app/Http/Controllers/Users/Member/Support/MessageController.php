<?php

namespace App\Http\Controllers\Users\Member\Support;

use App\Http\Controllers\Controller;
use App\Http\Requests\User\Member\Support\SupportMessageRequest;
use App\Models\SupportTicket;

class MessageController extends Controller
{
    public function store(SupportMessageRequest $request, $id)
    {

        $ticket = SupportTicket::where('uuid', $id)->firstOrFail();
        if ($request->user()->cannot('view', $ticket)) {
            abort(403);
        }
        $ticket->messages()->create([
            'message' => $request->get('message')
        ]);
    }


}
