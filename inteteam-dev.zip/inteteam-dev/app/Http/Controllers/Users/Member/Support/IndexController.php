<?php

namespace App\Http\Controllers\Users\Member\Support;

use App\DataTables\User\Member\SupportDataTable;
use App\Http\Controllers\Controller;
use App\Http\Requests\User\Member\Support\NewTicketRequest;
use App\Models\SupportCategory;
use App\Models\SupportPriority;
use App\Models\SupportTicket;
use Illuminate\Http\Request;

class IndexController extends Controller
{
    /**
     * Display a listing of the resource.
     *
     * @return \Illuminate\Http\Response
     */
    public function index(SupportDataTable $dataTable)
    {
        return $dataTable->render('user.member.support.index');
    }

    /**
     * Show the form for creating a new resource.
     *
     * @return \Illuminate\Http\Response
     */
    public function create()
    {
        $priority = SupportPriority::pluck('name', 'id');
        $category = SupportCategory::orderBy('name')->select('id', 'name')->get();

        return view('user.member.support.create')
            ->with('category', $category)
            ->with('priority', $priority);
    }

    /**
     * Store a newly created resource in storage.
     *
     * @param  Request  $request
     * @return \Illuminate\Http\Response
     */
    public function store(NewTicketRequest $request)
    {
        auth()->user()->tickets()->create([
            'title'               => $request->get('title'),
            'support_priority_id' => $request->get('priority'),
            'message'             => $request->get('message'),
            'support_category_id' => $request->get('category'),
            'notify'              => (bool) $request->get('notify'),
        ]);
        return redirect()->route('user.member.support.ticket.index');
    }

    /**
     * Display the specified resource.
     *
     * @param  SupportTicket  $supportTicket
     * @return \Illuminate\Http\Response
     */
    public function show(Request $request, SupportTicket $ticket)
    {
        if ($request->user()->cannot('view', $ticket)) {
            abort(403);
        }
        return view('user.member.support.show')
            ->with('ticket', $ticket->load('creator', 'priority', 'status', 'messages'));
    }

    /**
     * Show the form for editing the specified resource.
     *
     * @param  SupportTicket  $supportTicket
     * @return \Illuminate\Http\Response
     */
    public function edit(SupportTicket $supportTicket)
    {
        //
    }

    /**
     * Update the specified resource in storage.
     *
     * @param  Request  $request
     * @param  SupportTicket  $supportTicket
     * @return \Illuminate\Http\Response
     */
    public function update(Request $request, SupportTicket $supportTicket)
    {
        //
    }

    /**
     * Remove the specified resource from storage.
     *
     * @param  SupportTicket  $supportTicket
     * @return \Illuminate\Http\Response
     */
    public function destroy(SupportTicket $supportTicket)
    {
        //
    }
}
