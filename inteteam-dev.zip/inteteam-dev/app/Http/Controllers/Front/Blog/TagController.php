<?php

namespace App\Http\Controllers\Front\Blog;

use App\Http\Controllers\Controller;
use App\Models\Tag;

class TagController extends Controller
{
    public function show(Tag $tag)
    {
        return view('front.blog.index')
            ->with('headLine','Tag')
            ->with('posts', $tag->activePosts()->get()->load('creator'));

    }
}
