<?php

namespace App\Http\Controllers\Front\Blog;

use App\Http\Controllers\Controller;
use App\Models\Category;

class CategoryController extends Controller
{
    public function show(Category $category)
    {
        return view('front.blog.index')
            ->with('headLine','Category')
            ->with('posts', $category->activePosts()->get()->load('creator'));
    }
}
