<?php

namespace App\Http\Controllers\Front\Blog;

use App\Http\Controllers\Controller;
use App\Models\Post;
use Illuminate\Http\Request;

class ArchiveController extends Controller
{
    public function index(Request $request)
    {
        $posts = Post::with('creator')
            ->latest()
            ->blogArchives(['year' => $request->year, 'month' => $request->month])
            ->get();
        return view('front.blog.index')
            ->with('headLine', 'Archives')
            ->with('posts', $posts);
    }
}
