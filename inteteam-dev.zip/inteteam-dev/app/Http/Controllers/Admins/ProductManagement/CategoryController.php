<?php

namespace App\Http\Controllers\Admins\ProductManagement;

use App\Http\Controllers\Controller;
use App\Http\Requests\Admin\ProductsManagement\CategoryRequest;
use App\Http\Requests\Admin\ProductsManagement\CategoryUpdateRequest;
use App\Models\ProductCategory;
use App\Traits\StoreImageTrait;
use Illuminate\Http\Request;
use App\DataTables\Admin\ProductCategoryDataTable;

class CategoryController extends Controller
{
    use StoreImageTrait;

    /**
     * Display a listing of the resource.
     *
     * @return \Illuminate\Http\Response
     */
    public function index(ProductCategoryDataTable $dataTable)
    {
        return $dataTable->render('admin.products_management.category.index');
    }

    /**
     * Show the form for creating a new resource.
     *
     * @return \Illuminate\Http\Response
     */
    public function create()
    {
        $categories = ProductCategory::select('title', 'id')
            ->orderBy('title', 'asc')
            ->get();
        return view('admin.products_management.category.create')
            ->with('categories', $categories);
    }

    /**
     * Store a newly created resource in storage.
     *
     * @param  Request  $request
     * @return \Illuminate\Http\Response
     */
    public function store(CategoryRequest $request)
    {
        ProductCategory::create([
            'title'       => $request->get('title'),
            'description' => $request->get('description'),
            'status'      => (bool) $request->get('status'),
            'sort'        => $request->get('sort'),
            'parent_id'   => $request->get('parent'),
            'image_path'  => $this->uploadImage($request, '/media/images/product_category')
        ]);
        return redirect()->route('admin.product-management.category.index');
    }

    /**
     * Display the specified resource.
     *
     * @param  ProductCategory  $productCategory
     * @return \Illuminate\Http\Response
     */
    public function show(ProductCategory $category)
    {
        return view('admin.products_management.category.show')
            ->with('category', $category);
    }

    /**
     * Show the form for editing the specified resource.
     *
     * @param  ProductCategory  $productCategory
     * @return \Illuminate\Http\Response
     */
    public function edit(ProductCategory $category)
    {
        $categories = ProductCategory::select('title', 'id')
            ->orderBy('title', 'asc')
            ->get();
        return view('admin.products_management.category.edit')
            ->with('category', $category)
            ->with('categories', $categories);

    }

    /**
     * Update the specified resource in storage.
     *
     * @param  Request  $request
     * @param  ProductCategory  $productCategory
     * @return \Illuminate\Http\Response
     */
    public function update(CategoryUpdateRequest $request, ProductCategory $category)
    {
        if ($request->has('image')) {
            $this->deleteFile($category->image_path);
            $category->update(['image_path' => $this->uploadImage($request, '/media/images/product_category')]);

        }
        $category->update([
            'title'       => $request->get('title'),
            'description' => $request->get('description'),
            'status'      => (bool) $request->get('status'),
            'sort'        => $request->get('sort'),
            'parent_id'   => $request->get('parent'),
        ]);
        return redirect()->route('admin.product-management.category.index');
    }

    /**
     * Remove the specified resource from storage.
     *
     * @param  ProductCategory  $productCategory
     * @return \Illuminate\Http\Response
     */
    public function destroy(ProductCategory $category)
    {

        if ($category->image_path) {
            $this->deleteFile($category->image_path);
        }
        $category->delete();

        return response()->json('ok');
    }
}
