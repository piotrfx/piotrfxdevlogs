<?php

namespace App\Http\Controllers\Admins\ProductManagement;

use App\Helpers\LogActivity;
use App\Http\Controllers\Controller;
use App\Http\Requests\Admin\ProductsManagement\ProductRequest;
use App\Http\Requests\Admin\ProductsManagement\ProductUpdateRequest;
use App\Models\ActivityLog;
use App\Models\Product;
use App\Models\ProductCategory;
use App\Models\ProductType;
use App\Models\Supplier;
use Illuminate\Http\Request;
use Illuminate\Support\Collection;
use App\DataTables\Admin\ProductDataTable;

class ProductController extends Controller
{
    /**
     * Display a listing of the resource.
     *
     * @return \Illuminate\Http\Response
     */
    public function index(ProductDataTable $dataTable)
    {
        return $dataTable->render('admin.products_management.product.index');
    }

    /**
     * Show the form for creating a new resource.
     *
     * @return \Illuminate\Http\Response
     */
    public function create()
    {
        $categories = ProductCategory::select('id', 'title')->get();
        $suppliers = Supplier::select('id', 'name')->get();
        $productTypes = ProductType::select('id', 'name')->get();
        return view('admin.products_management.product.create')
            ->with('productTypes', $productTypes)
            ->with('suppliers', $suppliers)
            ->with('categories', $categories);
    }

    /**
     * Store a newly created resource in storage.
     *
     * @param  Request  $request
     * @return \Illuminate\Http\Response
     */
    public function store(ProductRequest $request)
    {


        $product = Product::create([
            'name'                => $request->get('name'),
            'product_category_id' => $request->get('category'),
            'image_path'          => \Storage::put('media/images/product', $request->file('image')),
            'price'               => $request->get('price'),
            'product_type_id'     => $request->get('product_type'),
            'sku'                 => $request->get('sku'),
            'qty'                 => $request->get('qty'),
            'description'         => $request->get('description'),
            'content'             => $request->get('content'),
            'supplier_id'         => $request->get('supplier'),
            'status'              => (bool) $request->get('status'),
            'available_at'        => $request->get('available_at')
        ]);
        if ($request->hasFile('images')) {
            $this->imageWrapper($request, $product);
        }
        return redirect()->route('admin.product-management.product.index');
    }

    /**
     * Display the specified resource.
     *
     * @param  Product  $product
     * @return \Illuminate\Http\Response
     */
    public function show(Product $product)
    {
        $product = $product->load('productCategory','productImages','productSupplier');
        return view('admin.products_management.product.show')->with('product', $product);
    }

    /**
     * Show the form for editing the specified resource.
     *
     * @param  Product  $product
     * @return \Illuminate\Http\Response
     */
    public function edit(Product $product)
    {
        $categories = ProductCategory::select('id', 'title')->get();
        $suppliers = Supplier::select('id', 'name')->get();
        $productTypes = ProductType::select('id', 'name')->get();
        return view('admin.products_management.product.edit')
            ->with('product', $product)
            ->with('productTypes', $productTypes)
            ->with('suppliers', $suppliers)
            ->with('categories', $categories);
    }

    /**
     * Update the specified resource in storage.
     *
     * @param  Request  $request
     * @param  Product  $product
     * @return \Illuminate\Http\Response
     */
    public function update(ProductUpdateRequest $request, Product $product)
    {
        $product->update([
            'name'                => $request->get('name'),
            'product_category_id' => $request->get('category'),
            'price'               => $request->get('price'),
            'product_type_id'     => $request->get('product_type'),
            'sku'                 => $request->get('sku'),
            'qty'                 => $request->get('qty'),
            'description'         => $request->get('description'),
            'content'             => $request->get('content'),
            'supplier_id'         => $request->get('supplier'),
            'status'              => (bool) $request->get('status'),
            'available_at'        => $request->get('available_at')
        ]);
        if ($request->file('image')) {
            \Storage::delete($product->image_path);
            $product->update([
                'image_path' => \Storage::put('media/images/product', $request->file('image')),
            ]);
        }
        if ($request->hasFile('images')) {

            $this->deleteImages($product);
            $this->imageWrapper($request, $product);
        }
        return redirect()->route('admin.product-management.product.index');
    }

    /**
     * Remove the specified resource from storage.
     *
     * @param  Product  $product
     * @return \Illuminate\Http\Response
     */
    public function destroy(Product $product)
    {
        //
    }

    /**
     * @param  Request  $request
     * @param  Product  $product
     */
    private function imageWrapper(Request $request, Product $product): void
    {
        $images = Collection::wrap($request->file('images'));
        $images->each(function ($image) use ($product) {
            $product->productImages()->create([
                'image_path' => \Storage::put('media/images/product/additional/'.$product->id, $image)
            ]);
        });
    }

    /**
     * @param  Product  $product
     */
    private function deleteImages(Product $product): void
    {
        foreach ($product->productImages as $productImage) {
            \Storage::delete($productImage->image_path);
            $productImage->delete();
        }
    }
}
