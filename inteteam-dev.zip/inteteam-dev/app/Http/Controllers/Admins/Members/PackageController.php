<?php

namespace App\Http\Controllers\Admins\Members;

use App\DataTables\Admin\Member\PackageDataTable;
use App\Helpers\LogActivity;
use App\Http\Controllers\Controller;
use App\Http\Requests\Admin\Member\PackageRequest;
use App\Models\MembershipPackage;
use Illuminate\Http\Request;

class PackageController extends Controller
{
    /**
     * Display a listing of the resource.
     *
     * @return \Illuminate\Http\Response
     */
    public function index(PackageDataTable $dataTable)
    {
        return $dataTable->render('admin.members.package.index');
    }

    /**
     * Show the form for creating a new resource.
     *
     * @return \Illuminate\Http\Response
     */
    public function create()
    {
        return view('admin.members.package.create');
    }

    /**
     * Store a newly created resource in storage.
     *
     * @param  Request  $request
     * @return \Illuminate\Http\Response
     */
    public function store(PackageRequest $request)
    {
        MembershipPackage::create($request->validated());
        return redirect()->route('admin.member.package.index');
    }

    /**
     * Display the specified resource.
     *
     * @param  MembershipPackage  $membershipPackage
     * @return \Illuminate\Http\Response
     */
    public function show(MembershipPackage $package)
    {
        return $package;
    }

    /**
     * Show the form for editing the specified resource.
     *
     * @param  MembershipPackage  $membershipPackage
     * @return \Illuminate\Http\Response
     */
    public function edit(MembershipPackage $package)
    {
        return view('admin.members.package.edit')
            ->with('package', $package);
    }

    /**
     * Update the specified resource in storage.
     *
     * @param  Request  $request
     * @param  MembershipPackage  $membershipPackage
     * @return \Illuminate\Http\Response
     */
    public function update(PackageRequest $request, MembershipPackage $package)
    {
        $package->update($request->validated());
        return redirect()->route('admin.member.package.index');
    }

    /**
     * Remove the specified resource from storage.
     *
     * @param  MembershipPackage  $membershipPackage
     * @return \Illuminate\Http\Response
     */
    public function destroy(MembershipPackage $package)
    {
        $package->delete();
        return redirect()->route('admin.member.package.index');
    }
}
