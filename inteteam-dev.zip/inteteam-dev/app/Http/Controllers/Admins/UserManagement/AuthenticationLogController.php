<?php

namespace App\Http\Controllers\Admins\UserManagement;

use App\Http\Controllers\Controller;
use App\Models\AuthenticationLog;
use App\DataTables\Admin\AuthenticationLogDataTable;

class AuthenticationLogController extends Controller
{
    public function index(AuthenticationLogDataTable $dataTable)
    {
        return $dataTable->render('admin.user_management.authentication_log.index');
    }

    public function show(AuthenticationLog $authenticationLog)
    {
        return $authenticationLog;
    }
}
