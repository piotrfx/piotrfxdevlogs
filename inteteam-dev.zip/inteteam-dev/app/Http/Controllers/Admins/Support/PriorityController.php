<?php

namespace App\Http\Controllers\Admins\Support;

use App\DataTables\Admin\Support\PriorityDataTable;
use App\Http\Controllers\Controller;
use App\Http\Requests\Admin\Support\PriorityRequest;
use App\Models\SupportPriority;
use Illuminate\Http\Request;

class PriorityController extends Controller
{
    public function index(PriorityDataTable $dataTable)
    {
        return $dataTable->render('admin.support.category.index');
    }

    public function create()
    {
        return view('admin.support.priority.create');
    }

    public function store(PriorityRequest $request)
    {
        SupportPriority::create($request->validated());
        return redirect()->route('admin.support.priority.index')
            ->with('success','Priority has been created');
    }

    public function show(SupportPriority $supportPriority)
    {
        //
    }

    public function edit(SupportPriority $priority)
    {
        return view('admin.support.priority.edit')
            ->with('priority', $priority);
    }

    public function update(PriorityRequest $request, SupportPriority $priority)
    {
        $priority->update($request->validated());
        return redirect()->route('admin.support.priority.index')
            ->with('success','Priority has been updated');
    }

    public function destroy(SupportPriority $priority)
    {
        $priority->delete();
        return response()->json('ok');
    }
}
