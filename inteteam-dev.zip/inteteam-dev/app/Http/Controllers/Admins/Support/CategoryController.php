<?php

namespace App\Http\Controllers\Admins\Support;

use App\DataTables\Admin\Support\CategoryDataTable;
use App\Helpers\LogActivity;
use App\Http\Controllers\Controller;
use App\Http\Requests\Admin\Support\CategoryRequest;
use App\Models\SupportCategory;
use Illuminate\Http\Request;

class CategoryController extends Controller
{
    /**
     * Display a listing of the resource.
     *
     * @return \Illuminate\Http\Response
     */
    public function index(CategoryDataTable $dataTables)
    {
        return $dataTables->render('admin.support.category.index');
    }

    /**
     * Show the form for creating a new resource.
     *
     * @return \Illuminate\Http\Response
     */
    public function create()
    {
        return view('admin.support.category.create');
    }

    /**
     * Store a newly created resource in storage.
     *
     * @param  Request  $request
     * @return \Illuminate\Http\Response
     */
    public function store(CategoryRequest $request)
    {
        SupportCategory::create($request->validated());
        return redirect()->route('admin.support.category.index')
            ->with('success','Category has been created');
    }

    /**
     * Display the specified resource.
     *
     * @param  SupportCategory  $supportCategory
     * @return \Illuminate\Http\Response
     */
    public function show(SupportCategory $supportCategory)
    {
        //
    }

    /**
     * Show the form for editing the specified resource.
     *
     * @param  SupportCategory  $supportCategory
     * @return \Illuminate\Http\Response
     */
    public function edit(SupportCategory $category)
    {
        return view('admin.support.category.edit')
            ->with('category', $category);
    }

    /**
     * Update the specified resource in storage.
     *
     * @param  Request  $request
     * @param  SupportCategory  $supportCategory
     * @return \Illuminate\Http\Response
     */
    public function update(CategoryRequest $request, SupportCategory $category)
    {
        $category->update($request->validated());
        return redirect()->route('admin.support.category.index');
    }

    /**
     * Remove the specified resource from storage.
     *
     * @param  SupportCategory  $supportCategory
     * @return \Illuminate\Http\Response
     */
    public function destroy(SupportCategory $category)
    {
        $category->delete();
        return response()->json('ok');
    }
}
