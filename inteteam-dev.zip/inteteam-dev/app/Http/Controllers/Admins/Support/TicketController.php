<?php

namespace App\Http\Controllers\Admins\Support;

use App\DataTables\Admin\TicketDataTable;
use App\Http\Controllers\Controller;
use App\Mail\System\Support\AssignAgent;
use App\Models\SupportTicket;
use App\Models\User;
use Illuminate\Http\Request;

class TicketController extends Controller
{
    /**
     * Display a listing of the resource.
     *
     * @return \Illuminate\Http\Response
     */
    public function index(TicketDataTable $dataTable)
    {
        return $dataTable->render('admin.support.ticket.index');
    }

    /**
     * Show the form for creating a new resource.
     *
     * @return \Illuminate\Http\Response
     */
    public function create()
    {
        //
    }

    /**
     * Store a newly created resource in storage.
     *
     * @param  Request  $request
     * @return \Illuminate\Http\Response
     */
    public function store(Request $request)
    {
        $this->validate($request, [
            'agent' => 'exists:users,id',
        ]);

        $ticket = SupportTicket::findOrFail($request->get('id'));
        $ticket->update([
            'agent_id' => $request->get('agent')
        ]);
        $ticket->refresh();
        \Mail::to($ticket->agent->email)->send(new AssignAgent($ticket));

        return redirect()->route('admin.support.ticket.index');
    }

    /**
     * Display the specified resource.
     *
     * @param  SupportTicket  $supportTicket
     * @return \Illuminate\Http\Response
     */
    public function show(SupportTicket $ticket)
    {
        $agents = User::role('Support')->get();
        return view('admin.support.ticket.show')
            ->with('agents', $agents)
            ->with('ticket', $ticket->load('creator', 'priority', 'status', 'agent'));
    }

    /**
     * Show the form for editing the specified resource.
     *
     * @param  SupportTicket  $supportTicket
     * @return \Illuminate\Http\Response
     */
    public function edit(SupportTicket $ticket)
    {
        //
    }

    /**
     * Update the specified resource in storage.
     *
     * @param  Request  $request
     * @param  SupportTicket  $supportTicket
     * @return \Illuminate\Http\Response
     */
    public function update(Request $request, SupportTicket $ticket)
    {
        //
    }

    /**
     * Remove the specified resource from storage.
     *
     * @param  SupportTicket  $supportTicket
     * @return \Illuminate\Http\Response
     */
    public function destroy(SupportTicket $ticket)
    {
        //
    }
}
