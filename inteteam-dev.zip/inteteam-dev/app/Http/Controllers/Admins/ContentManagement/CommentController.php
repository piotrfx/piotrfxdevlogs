<?php

namespace App\Http\Controllers\Admins\ContentManagement;

use App\Http\Controllers\Controller;
use App\Http\Requests\Admin\ContentManagement\CommentRequest;
use App\Models\Post;
use App\Models\PostComment;
use App\Models\User;
use Illuminate\Http\Request;
use App\DataTables\Admin\PostCommentDataTable;

class CommentController extends Controller
{
    /**
     * Display a listing of the resource.
     *
     * @return \Illuminate\Http\Response
     */
    public function index(PostCommentDataTable $dataTable)
    {
        return $dataTable->render('admin.content_management.comment.index');
    }

    /**
     * Show the form for creating a new resource.
     *
     * @return \Illuminate\Http\Response
     */
    public function create()
    {
        //
    }

    /**
     * Store a newly created resource in storage.
     *
     * @param  Request  $request
     * @return \Illuminate\Http\Response
     */
    public function store(Request $request)
    {
        //
    }

    /**
     * Display the specified resource.
     *
     * @param  PostComment  $postComment
     * @return \Illuminate\Http\Response
     */
    public function show(PostComment $comment)
    {
        return $comment;
    }

    /**
     * Show the form for editing the specified resource.
     *
     * @param  PostComment  $postComment
     * @return \Illuminate\Http\Response
     */
    public function edit(PostComment $comment)
    {
        $posts = Post::select('title', 'id')->get();
        $users = User::select('first_name', 'last_name', 'id')->get();
        return view('admin.content_management.comment.edit')
            ->with('posts', $posts)
            ->with('users', $users)
            ->with('comment', $comment);
    }

    /**
     * Update the specified resource in storage.
     *
     * @param  Request  $request
     * @param  PostComment  $postComment
     * @return \Illuminate\Http\Response
     */
    public function update(CommentRequest $request, PostComment $comment)
    {
        $comment->update([
            'user_id' => $request->get('creator'),
            'post_id' => $request->get('post'),
            'body'    => $request->get('body')
        ]);
        return redirect()->route('admin.content-management.comment.index');
    }

    /**
     * Remove the specified resource from storage.
     *
     * @param  PostComment  $postComment
     * @return \Illuminate\Http\Response
     */
    public function destroy(PostComment $comment)
    {
        $comment->delete();
        return redirect()->route('admin.content-management.comment.index');
    }
}
