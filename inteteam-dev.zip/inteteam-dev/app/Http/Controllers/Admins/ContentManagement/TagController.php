<?php

namespace App\Http\Controllers\Admins\ContentManagement;

use App\Http\Controllers\Controller;
use App\Http\Requests\Admin\ContentManagement\TagRequest;
use App\Models\Tag;
use Illuminate\Http\Request;
use App\DataTables\Admin\TagDataTable;

class TagController extends Controller
{
    /**
     * Display a listing of the resource.
     *
     * @return \Illuminate\Http\Response
     */
    public function index(TagDataTable $dataTable)
    {
        return $dataTable->render('admin.content_management.tag.index');
    }

    /**
     * Show the form for creating a new resource.
     *
     * @return \Illuminate\Http\Response
     */
    public function create()
    {
        return view('admin.content_management.tag.create');
    }

    /**
     * Store a newly created resource in storage.
     *
     * @param  Request  $request
     * @return \Illuminate\Http\RedirectResponse
     */
    public function store(TagRequest $request)
    {
        Tag::create([
            'name'   => $request->get('name'),
            'status' => (bool) $request->get('status')
        ]);
        return redirect()->route('admin.content-management.tag.index')
            ->with('success', 'Tag has been added');
    }

    /**
     * Display the specified resource.
     *
     * @param  Tag  $tag
     * @return \Illuminate\Http\Response
     */
    public function show(Tag $tag)
    {
        return view('admin.content_management.tag.show')
            ->with('tag', $tag);

    }

    /**
     * Show the form for editing the specified resource.
     *
     * @param  Tag  $tag
     * @return \Illuminate\Contracts\Foundation\Application|\Illuminate\Contracts\View\Factory|\Illuminate\Contracts\View\View
     */
    public function edit(Tag $tag)
    {
        return view('admin.content_management.tag.edit')
            ->with('tag', $tag);
    }

    /**
     * Update the specified resource in storage.
     *
     * @param  Request  $request
     * @param  Tag  $tag
     * @return \Illuminate\Http\RedirectResponse
     */
    public function update(Request $request, Tag $tag)
    {
        $tag->update([
            'name'   => $request->get('name'),
            'status' => (bool) $request->get('status')
        ]);
        return redirect()->route('admin.content-management.tag.index')
            ->with('success', 'Tag has been updated');;
    }

    /**
     * Remove the specified resource from storage.
     *
     * @param  Tag  $tag
     * @return \Illuminate\Http\Response
     */
    public function destroy(Tag $tag)
    {
        $tag->delete();
        return response()->json('ok');
    }
}
