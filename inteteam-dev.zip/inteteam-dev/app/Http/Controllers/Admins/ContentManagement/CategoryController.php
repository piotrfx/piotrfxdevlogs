<?php

namespace App\Http\Controllers\Admins\ContentManagement;

use App\Helpers\LogActivity;
use App\Http\Controllers\Controller;
use App\Http\Requests\Admin\ContentManagement\CategoryRequest;
use App\Models\Category;
use Illuminate\Http\Request;
use App\DataTables\Admin\CategoryDataTable;

class CategoryController extends Controller
{

    /**
     * Display a listing of the resource.
     *
     * @return \Illuminate\Http\Response
     */
    public function index(CategoryDataTable $dataTable)
    {

        return $dataTable->render('admin.content_management.category.index');
    }

    /**
     * Show the form for creating a new resource.
     *
     * @return \Illuminate\Http\Response
     */
    public function create()
    {
        return view('admin.content_management.category.create');
    }

    /**
     * Store a newly created resource in storage.
     *
     * @param  Request  $request
     * @return \Illuminate\Http\Response
     */
    public function store(CategoryRequest $request)
    {
        Category::create([
            'name'   => $request->get('name'),
            'status' => (bool) $request->get('status')
        ]);
        return redirect()->route('admin.content-management.category.index')
            ->with('success', 'category has been created');
    }

    /**
     * Display the specified resource.
     *
     * @param  Category  $category
     * @return \Illuminate\Http\Response
     */
    public function show(Category $category)
    {
        return view('admin.content_management.category.show')->with('category', $category);
    }

    /**
     * Show the form for editing the specified resource.
     *
     * @param  Category  $category
     * @return \Illuminate\Http\Response
     */
    public function edit(Category $category)
    {
        return view('admin.content_management.category.edit')
            ->with('category', $category);
    }

    /**
     * Update the specified resource in storage.
     *
     * @param  Request  $request
     * @param  Category  $category
     * @return \Illuminate\Http\Response
     */
    public function update(CategoryRequest $request, Category $category)
    {
        $category->update([
            'name'   => $request->get('name'),
            'status' => (bool) $request->get('status')
        ]);

        return redirect()->route('admin.content-management.category.index');
    }

    /**
     * Remove the specified resource from storage.
     *
     * @param  Category  $category
     * @return \Illuminate\Http\Response
     */
    public function destroy(Category $category)
    {
        $category->delete();
        return response()->json('ok');
    }
}
