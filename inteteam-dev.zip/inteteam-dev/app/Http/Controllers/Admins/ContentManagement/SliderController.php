<?php

namespace App\Http\Controllers\Admins\ContentManagement;

use App\DataTables\Admin\SliderDataTable;
use App\Helpers\LogActivity;
use App\Http\Controllers\Controller;
use App\Http\Requests\Admin\ContentManagement\SliderRequest;
use App\Http\Requests\Admin\ContentManagement\SliderUpdateRequest;
use App\Models\Slider;
use Illuminate\Http\Request;
use App\Traits\StoreImageTrait;

class SliderController extends Controller
{
    use StoreImageTrait;

    /**
     * Display a listing of the resource.
     *
     * @return \Illuminate\Http\Response
     */
    public function index(SliderDataTable $dataTable)
    {
        return $dataTable->render('admin.content_management.slider.index');
    }

    /**
     * Show the form for creating a new resource.
     *
     * @return \Illuminate\Http\Response
     */
    public function create()
    {
        return view('admin.content_management.slider.create');
    }

    /**
     * Store a newly created resource in storage.
     *
     * @param  Request  $request
     * @return \Illuminate\Http\Response
     */
    public function store(SliderRequest $request)
    {
        Slider::create([
            'name'       => $request->get('name'),
            'body'       => $request->get('body'),
            'status'     => (bool) $request->get('status'),
            'image_path' => $this->uploadImage($request, '/media/images/slider', true, 900)
        ]);
        return redirect()->route('admin.content-management.slider.index');
    }

    /**
     * Display the specified resource.
     *
     * @param  Slider  $slider
     * @return \Illuminate\Http\Response
     */
    public function show(Slider $slider)
    {
        return view('admin.content_management.slider.show')->with('slider', $slider);
    }

    /**
     * Show the form for editing the specified resource.
     *
     * @param  Slider  $slider
     * @return \Illuminate\Http\Response
     */
    public function edit(Slider $slider)
    {
        return view('admin.content_management.slider.edit')
            ->with('slider', $slider);
    }

    /**
     * Update the specified resource in storage.
     *
     * @param  Request  $request
     * @param  Slider  $slider
     * @return \Illuminate\Http\Response
     */
    public function update(SliderUpdateRequest $request, Slider $slider)
    {
        $data = [
            'name'   => $request->get('name'),
            'body'   => $request->get('body'),
            'status' => (bool) $request->get('status'),
        ];
        if ($request->has('image')) {
            $this->deleteFile($slider->image_path);
            $data['image_path'] = $this->uploadImage($request, '/media/images/slider', true, 900);
        }
        $slider->update($data);
        return redirect()->route('admin.content-management.slider.index');
    }

    /**
     * Remove the specified resource from storage.
     *
     * @param  Slider  $slider
     * @return \Illuminate\Http\Response
     */
    public function destroy(Slider $slider)
    {
        $this->deleteFile($slider->image_path);
        $slider->delete();
        return response()->json('ok');
    }
}
