<?php

namespace App\Http\Controllers\Admins\ContentManagement;

use App\DataTables\Admin\PostDataTable;
use App\Http\Controllers\Controller;
use App\Http\Requests\Admin\ContentManagement\PostRequest;
use App\Http\Requests\Admin\ContentManagement\PostUpdateRequest;
use App\Models\Category;
use App\Models\Post;
use App\Models\Tag;
use App\Models\User;
use App\Traits\StoreImageTrait;
use Illuminate\Http\Request;

class PostController extends Controller
{
    use StoreImageTrait;

    /**
     * Display a listing of the resource.
     *
     * @return \Illuminate\Http\Response
     */
    public function index(PostDataTable $dataTable)
    {
        return $dataTable->render('admin.content_management.post.index');
    }

    /**
     * Show the form for creating a new resource.
     *
     * @return \Illuminate\Http\Response
     */
    public function create()
    {
        $users = User::all();
        $categories = Category::select('id', 'name')->get();
        $tags = Tag::select('id', 'name')->get();
        return view('admin.content_management.post.create')
            ->with('users', $users)
            ->with('categories', $categories)
            ->with('tags', $tags);
    }

    /**
     * Store a newly created resource in storage.
     *
     * @param  Request  $request
     * @return \Illuminate\Http\Response
     */
    public function store(PostRequest $request)
    {

        $post = Post::create([
            'title'       => $request->get('title'),
            'user_id'     => $request->get('user'),
            'category_id' => $request->get('category'),
            'image_path'  => ($request->has('image')) ? $this->uploadImage($request, '/media/images/post', true,
                900) : null,
            'body'        => $request->get('body'),
            'status'      => (bool) $request->get('status'),
        ]);
        $post->tags()->attach($request->get('tags'));
        return redirect()->route('admin.content-management.post.index');
    }

    /**
     * Display the specified resource.
     *
     * @param  Post  $post
     * @return \Illuminate\Http\Response
     */
    public function show(Post $post)
    {
        $comments = $post->comments()->latest()->paginate(10);
        return view('admin.content_management.post.show')
            ->with('post', $post)
            ->with('comments', $comments);
    }

    /**
     * Show the form for editing the specified resource.
     *
     * @param  Post  $post
     * @return \Illuminate\Http\Response
     */
    public function edit(Post $post)
    {
        $users = User::all();
        $categories = Category::select('id', 'name')->get();
        $tags = Tag::select('id', 'name')->get();
        return view('admin.content_management.post.edit')
            ->with('post', $post)
            ->with('users', $users)
            ->with('categories', $categories)
            ->with('tags', $tags);
    }

    /**
     * Update the specified resource in storage.
     *
     * @param  Request  $request
     * @param  Post  $post
     * @return \Illuminate\Http\Response
     */
    public function update(PostRequest $request, Post $post)
    {
        $data = [
            'title'       => $request->get('title'),
            'user_id'     => $request->get('user'),
            'category_id' => $request->get('category'),
            'body'        => $request->get('body'),
            'status'      => (bool) $request->get('status'),
        ];
        if ($request->has('image')) {
            if ($post->image_path) {
                $this->deleteFile($post->image_path);
            }
            $data['image_path'] = $this->uploadImage($request, '/media/images/post', true, 900);

        }
        $post->update($data);
        $post->tags()->sync($request->get('tags'));
        return redirect()->route('admin.content-management.post.index')
            ->with('success', 'Post has been updated');
    }

    /**
     * Remove the specified resource from storage.
     *
     * @param  Post  $post
     * @return \Illuminate\Http\Response
     */
    public function destroy(Post $post)
    {
        $this->deleteFile($post->image_path);
        $post->delete();
        return response()->json('ok');
    }
}
