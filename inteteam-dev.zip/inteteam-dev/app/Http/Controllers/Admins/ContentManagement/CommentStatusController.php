<?php

namespace App\Http\Controllers\Admins\ContentManagement;

use App\Http\Controllers\Controller;
use App\Models\PostComment;

class CommentStatusController extends Controller
{
    public function status($id, $status)
    {
        $comment = PostComment::findOrFail($id);
        $comment->update([
            'is_disabled' => $status
        ]);
        return redirect()->route('admin.content-management.comment.index');
    }
}
