<?php

namespace App\Http\Controllers\Admins\PageManagement;

use App\Http\Controllers\Controller;
use App\Http\Requests\Admin\PageManagement\FaqCategoryRequest;
use App\Models\FaqCategory;
use Illuminate\Http\Request;
use App\DataTables\Admin\FaqCategoryDataTable;

class FaqCategoryController extends Controller
{
    /**
     * Display a listing of the resource.
     *
     * @return \Illuminate\Http\Response
     */
    public function index(FaqCategoryDataTable $dataTable)
    {
        return $dataTable->render('admin.page_management.faq_category.index');
    }

    /**
     * Show the form for creating a new resource.
     *
     * @return \Illuminate\Http\Response
     */
    public function create()
    {
        return view('admin.page_management.faq_category.create');
    }

    /**
     * Store a newly created resource in storage.
     *
     * @param  Request  $request
     * @return \Illuminate\Http\Response
     */
    public function store(FaqCategoryRequest $request)
    {
        FaqCategory::create([
            'name' => $request->get('name')
        ]);
        return redirect()->route('admin.page-management.faq-category.index');
    }

    /**
     * Display the specified resource.
     *
     * @param  FaqCategory  $faqCategory
     * @return \Illuminate\Http\Response
     */
    public function show(FaqCategory $faqCategory)
    {
        return $faqCategory;
    }

    /**
     * Show the form for editing the specified resource.
     *
     * @param  FaqCategory  $faqCategory
     * @return \Illuminate\Http\Response
     */
    public function edit(FaqCategory $faqCategory)
    {
        return view('admin.page_management.faq_category.edit')
            ->with('category', $faqCategory);
    }

    /**
     * Update the specified resource in storage.
     *
     * @param  Request  $request
     * @param  FaqCategory  $faqCategory
     * @return \Illuminate\Http\Response
     */
    public function update(FaqCategoryRequest $request, FaqCategory $faqCategory)
    {
        $faqCategory->update([
            'name' => $request->get('name')
        ]);
        return redirect()->route('admin.page-management.faq-category.index');
    }

    /**
     * Remove the specified resource from storage.
     *
     * @param  FaqCategory  $faqCategory
     * @return \Illuminate\Http\Response
     */
    public function destroy(FaqCategory $faqCategory)
    {
        $faqCategory->delete();
        return response()->json('ok');
    }
}
