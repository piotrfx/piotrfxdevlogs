<?php

namespace App\Http\Controllers\Admins\PageManagement;

use App\Http\Controllers\Controller;
use App\Http\Requests\Admin\PageManagement\FaqRequest;
use App\Models\Faq;
use App\Models\FaqCategory;
use Illuminate\Http\Request;
use App\DataTables\Admin\FaqDataTable;

class FaqController extends Controller
{
    /**
     * Display a listing of the resource.
     *
     * @return \Illuminate\Http\Response
     */
    public function index(FaqDataTable $dataTable)
    {
        return $dataTable->render('admin.page_management.faq.index');
    }

    /**
     * Show the form for creating a new resource.
     *
     * @return \Illuminate\Http\Response
     */
    public function create()
    {
        $categories = FaqCategory::all();
        return view('admin.page_management.faq.create')
            ->with('categories', $categories);
    }

    /**
     * Store a newly created resource in storage.
     *
     * @param  Request  $request
     * @return \Illuminate\Http\Response
     */
    public function store(FaqRequest $request)
    {
        Faq::create([
            'question'        => $request->get('question'),
            'answer'          => $request->get('answer'),
            'faq_category_id' => $request->get('category')
        ]);
        return redirect()->route('admin.page-management.faq.index');
    }

    /**
     * Display the specified resource.
     *
     * @param  Faq  $faq
     * @return \Illuminate\Http\Response
     */
    public function show(Faq $faq)
    {
        return view('admin.page_management.faq.show')
            ->with('faq',$faq);
    }

    /**
     * Show the form for editing the specified resource.
     *
     * @param  Faq  $faq
     * @return \Illuminate\Http\Response
     */
    public function edit(Faq $faq)
    {
        $categories = FaqCategory::all();
        return view('admin.page_management.faq.edit')
            ->with('categories', $categories)
            ->with('faq', $faq);
    }

    /**
     * Update the specified resource in storage.
     *
     * @param  Request  $request
     * @param  Faq  $faq
     * @return \Illuminate\Http\Response
     */
    public function update(FaqRequest $request, Faq $faq)
    {
        $faq->update([
            'question'        => $request->get('question'),
            'answer'          => $request->get('answer'),
            'faq_category_id' => $request->get('category')
        ]);
        return redirect()->route('admin.page-management.faq.index');
    }

    /**
     * Remove the specified resource from storage.
     *
     * @param  Faq  $faq
     * @return \Illuminate\Http\Response
     */
    public function destroy(Faq $faq)
    {
        $faq->delete();
        return response()->json('ok');
    }
}
