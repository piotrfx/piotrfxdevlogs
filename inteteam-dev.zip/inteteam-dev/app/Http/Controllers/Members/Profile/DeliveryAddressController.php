<?php

namespace App\Http\Controllers\Members\Profile;

use App\DataTables\Member\Adress\UserAdressDataTable;
use App\Http\Controllers\Controller;
use App\Http\Requests\User\Profile\DeliveryAddressRequest;
use App\Models\Country;
use App\Models\UserDeliveryAddress;
use Illuminate\Http\Request;

class DeliveryAddressController extends Controller
{
    /**
     * Display a listing of the resource.
     *
     * @return \Illuminate\Http\Response
     */
    public function index(UserAdressDataTable $dataTable)
    {
        return $dataTable->render('member.profile.delivery_address.index');
    }

    /**
     * Show the form for creating a new resource.
     *
     * @return \Illuminate\Http\Response
     */
    public function create()
    {
        $counties = Country::all();
        return view('member.profile.delivery_address.create')
            ->with('countries', $counties);
    }

    /**
     * Store a newly created resource in storage.
     *
     * @param  Request  $request
     * @return \Illuminate\Http\Response
     */
    public function store(DeliveryAddressRequest $request)
    {

        if ($request->get('default') ) {
            if ($address = auth()->user()->defaultDeliveryAddress()) {
                $address->update(['is_default' => false]);
            }

        }
        auth()->user()->deliveryAddresses()->create([
            'name' => $request->get('name'),
            'address_line_1' => $request->get('address_line_1'),
            'address_line_2' => $request->get('address_line_2'),
            'postcode'       => $request->get('postcode'),
            'city'           => $request->get('city'),
            'country_id'     => $request->get('country'),
            'instruction'    => $request->get('instruction'),
            'is_default'     => (bool) $request->get('default')
        ]);
        return redirect()->route('member.profile.address.index');

    }

    /**
     * Display the specified resource.
     *
     * @param  UserDeliveryAddress  $deliveryAddress
     * @return \Illuminate\Http\Response
     */
    public function show(UserDeliveryAddress $address)
    {
        return $address;
    }

    /**
     * Show the form for editing the specified resource.
     *
     * @param  UserDeliveryAddress  $deliveryAddress
     * @return \Illuminate\Http\Response
     */
    public function edit(UserDeliveryAddress $address) 
    {

        $counties = Country::all();
        return view('member.profile.delivery_address.edit')
            ->with('countries', $counties)
            ->with('address', $address);
    }

    /**
     * Update the specified resource in storage.
     *
     * @param  Request  $request
     * @param  UserDeliveryAddress  $deliveryAddress
     * @return \Illuminate\Http\Response
     */
    public function update(Request $request, UserDeliveryAddress $address)
    {
        if ($request->get('default')) {
            auth()->user()->defaultDeliveryAddress()->update(['is_default' => false]);
        }
        $address->update([
            'name' => $request->get('name'),
            'address_line_1' => $request->get('address_line_1'),
            'address_line_2' => $request->get('address_line_2'),
            'postcode'       => $request->get('postcode'),
            'city'           => $request->get('city'),
            'country_id'     => $request->get('country'),
            'instruction'    => $request->get('instruction'),
            'is_default'     => (bool) $request->get('default')
        ]);
        return redirect()->route('member.profile.address.index');
    }

    /**
     * Remove the specified resource from storage.
     *
     * @param  UserDeliveryAddress  $deliveryAddress
     * @return \Illuminate\Http\Response
     */
    public function destroy( UserDeliveryAddress $address)
    {
        $address->delete();
        return response()->json('ok'); //jesli kasujesz przez sweeta lret jak jest teraz to musisz wyslac responze ok wtedy tabelka sie przeladuje :D 
    }
}
