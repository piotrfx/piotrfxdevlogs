<?php

namespace App\Http\Controllers\Members\Profile;

use App\Http\Controllers\Controller;
use App\Http\Requests\User\Profile\ProfileUpdateRequest;
use App\Models\Country;
use Illuminate\Http\Request;

class ProfileController extends Controller
{
    public function show()
    {
        //display user profile
        return view('member.profile.account_details.index')
        ->with('profile', auth()->user()->load('profile'));
    }

    public function edit()
    {

        $counties = Country::all();
        $adresses = auth()->user()->deliveryAddresses;
        return view('member.profile.account_details.edit')
            ->with('profile', auth()->user()->load('profile'))
            ->with('adresses', $adresses)->with('countries', $counties);

    }

    public function update(ProfileUpdateRequest $request)
    {
        $update = [
            'first_name' => $request->get('first_name'),
            'last_name'  => $request->get('last_name'),
            'email'      => $request->get('email'),
            'personality'  => $request->get('personality'),
        ];
        if ($request->get('password') && !\Hash::check($request->get('password'), auth()->user()->password)) {
            $update['password'] = $request->get('password');
        }
        auth()->user()->update($update);
        if ($request->get('phone') != auth()->user()->profile->phone) {
            auth()->user()->profile->update([
                'phone' => $request->get('phone')
            ]);
        }
        $profile = [
            'delivery_address_id' => $request->get('delivery_address'),
            'reply_address_id'    => $request->get('reply_address')
        ];
        if ($request->get('description') != auth()->user()->profile->description) {
            $profile['description'] = $request->get('description');
        }
        if ($request->hasFile('avatar')) {
            if (auth()->user()->profile->avatar) {
                \Storage::delete(auth()->user()->profile->avatar);
            }
            $profile['avatar'] = \Storage::put('/media/images/users/avatars', $request->file('avatar'));
        }
        auth()->user()->profile()->update($profile);
        return redirect()->route('member.profile.show')
 ->with('message', 'Profile has been updated');
    }
}
