<?php

namespace App\Http\Controllers\Members;

use App\Http\Controllers\Controller;
use Illuminate\Http\Request;

class DashboardController extends Controller
{
    public function index()
    {
        return view('member.index')
        ->with('cash',optional(auth()->user()->wallet)->available_amount)
        ->with('invite', auth()->user()->invite->count());
    }
}
