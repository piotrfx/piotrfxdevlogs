<?php

namespace App\Http\Controllers\Members\Teamchat;

use App\Http\Controllers\Controller;
use App\Http\Resources\Members\Chat\ContactCollection;
use App\Http\Resources\Members\Chat\ContactResource;
use App\Models\ChatMessage;
use App\Models\User;

class ContactController extends Controller
{
    public function index()
    {
        //allow only ajax calls
        if (request()->ajax()) {

            // get all users except the authenticated one and users which want to chat
            $contacts = User::with('profile')->select(['first_name', 'last_name', 'email', 'id'])
                //select users by role - admin or exhibitor
                ->when(request('role') != 'null', function ($q) {
                    $q->role(request('role'));
                })
                ->where([
                    ['id', '!=', auth()->id()]
                ])
                ->orderBy('first_name')
                ->get();

            // get a collection of items where sender_id is the user who sent us a message
            // and messages_count is the number of unread messages we have from him
            $unreadIds = ChatMessage::select(\DB::raw('`from` as sender_id, count(`from`) as messages_count'))
                ->where([
                    ['to', '=', auth()->id()],
                    ['read', '=', false]
                ])
                ->groupBy('from')
                ->get();

            // add an unread key to each contact with the count of unread messages
            $contacts = $contacts->map(function ($contact) use ($unreadIds) {
                $contactUnread = $unreadIds->where('sender_id', $contact->id)->first();
                $contact->unread = $contactUnread ? $contactUnread->messages_count : 0;
                return $contact;
            });
            return new ContactCollection($contacts);
        }
        //send 403 response
        return response()->json('Access Denied', 403);
    }
}
