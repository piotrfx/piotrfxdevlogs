<?php

namespace App\Http\Controllers\Partners\Shop;

use App\Http\Controllers\Controller;
use Illuminate\Contracts\View\View;
use Illuminate\Http\Request;

class ShopController extends Controller
{
    /**
     * @return View
     */
    public function orders(): View
    {
        return view('partner.shop.orders');
    }

    /**
     * @return View
     */
    public function wishlist(): View
    {
        return view('partner.shop.wishlist');
    }

    /**
     * @return View
     */
    public function favourite(): View
    {
        return view('partner.shop.favourite');
    }
}
