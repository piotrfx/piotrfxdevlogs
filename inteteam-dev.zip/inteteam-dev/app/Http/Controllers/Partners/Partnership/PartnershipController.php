<?php

namespace App\Http\Controllers\Partners\Partnership;

use App\Http\Controllers\Controller;
use Illuminate\Contracts\View\View;
use Illuminate\Http\Request;

class PartnershipController extends Controller
{
    /**
     * @return View
     */
    public function index(): View
    {
        return view('partner.partnership.index');
    }
}
