<?php

namespace App\Http\Controllers\Partners\Ewallet;

use App\Http\Controllers\Controller;
use Illuminate\Contracts\View\View;
use Illuminate\Http\Request;

class EwalletController extends Controller
{
    /**
     * @return View
     */
    public function index(): View
    {
        return view('partner.ewallet.index')->with('user', auth()->user());
    }
}
