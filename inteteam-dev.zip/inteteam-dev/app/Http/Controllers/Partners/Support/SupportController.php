<?php

namespace App\Http\Controllers\Partners\Support;

use App\DataTables\Partner\Tickets\PartnerTicketDataTable;
use App\Http\Controllers\Controller;
use Illuminate\Contracts\View\View;
use Illuminate\Http\Request;

class SupportController extends Controller
{
    /**
     * @return View
     */
    public function index(PartnerTicketDataTable $dataTable)
    {
        return $dataTable->render('partner.support.index');
    }
}
