<?php

namespace App\Traits;

use Illuminate\Http\Request;
use Image;
use Storage;

trait StoreImageTrait
{
    public function __construct()
    {
        $this->disk = config('filesystems.default');
    }

    public function uploadImage(Request $request, $dir, $resize = false, $width = null): string
    {
        $path = Storage::disk($this->disk)->put($dir, $request->file('image'));
        if ($resize && $width) {
            $this->resizeImage($path, $width, $dir);
        }

        return $path;
    }

    public function deleteFile($file = null)
    {
        if ($file) {
            Storage::disk($this->disk)->delete($file);
        }
    }

    protected function resizeImage($file, $width)
    {
        $temp = Image::make(Storage::get($file))
            ->resize($width, null, function ($constraint) {
                $constraint->aspectRatio();
            })->stream();
        Storage::disk($this->disk)->put($file, $temp);
    }
}
