<?php

namespace App\Models;

use Illuminate\Database\Eloquent\Model;
use Illuminate\Database\Eloquent\Relations\BelongsTo;
use Illuminate\Support\Str;

class ChatMessage extends Model
{
    //fillable columns
    protected $fillable = [
        'from',
        'to',
        'text',
        'read',
    ];
    //casts
    protected $casts = [
        'created_at' => 'datetime:H:i:s d/m/Y',
        'updated_at' => 'datetime:d/m/Y H:i:s',
    ];
    protected $appends = ['message'];
    protected $with = ['authorMessage'];
    // Relations
    public function fromContact(): \Illuminate\Database\Eloquent\Relations\HasOne
    {
        return $this->hasOne(User::class, 'id', 'from')->select(['id', 'email', 'first_name', 'last_name']);
    }
    public function getMessageAttribute()
    {
        return Str::limit($this->text, 35, '...');
    }
    public function authorMessage(): BelongsTo
    {
        return $this->belongsTo(User::class, 'from', 'id');
    }
}
