<?php

namespace App\Models;

use Illuminate\Database\Eloquent\Model;
use Illuminate\Database\Eloquent\Relations\BelongsTo;
use Propaganistas\LaravelPhone\Casts\RawPhoneNumberCast;

class UserProfile extends Model
{
    protected $fillable = [
        'delivery_address',
        'reply_adress',
        'phone',
        'avatar',
        'user_id',
        'description'
    ];
    protected $casts = [
        //'phone'=>RawPhoneNumberCast::class.':GB',
        'created_at' => 'datetime:d/m/Y H:i:s',
        'updated_at' => 'datetime:d/m/Y H:i:s',
    ];
    protected $appends =['user_avatar'];
    public function user(): BelongsTo
    {
        return $this->belongsTo(User::class);
    }

    public function getUserAvatarAttribute()
    {
        return ($this->avatar) ? \Storage::url($this->avatar) : \Storage::url('/media/images/avatar/default.png');
    }
    public function deliveryAddress(): BelongsTo
    {
        return $this->belongsTo(UserDeliveryAddress::class,'delivery_address_id','id');
    }

    public function replyAddress(): BelongsTo
    {
        return $this->belongsTo(UserDeliveryAddress::class,'reply_address_id','id');
    }
}
