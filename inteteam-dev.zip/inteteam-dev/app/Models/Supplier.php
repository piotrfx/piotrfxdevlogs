<?php

namespace App\Models;

use Illuminate\Database\Eloquent\Factories\HasFactory;
use Illuminate\Database\Eloquent\Model;
use Illuminate\Database\Eloquent\Relations\HasMany;

class Supplier extends Model
{
    use HasFactory;
    protected $fillable = [
        'slug',
        'name',
        'description',
        'first_line_address',
        'second_line_address',
        'post_code',
        'town',
        'contact_email',
        'contact_phone',
        'vat_no',
        'form_of_payment',
        'bank_name',
        'sort_code',
        'account_number',
        'registration_number'
    ];
    protected $casts = [
        'created_at' => 'datetime:d/m/Y H:i:s',
        'updated_at' => 'datetime:d/m/Y H:i:s',
    ];

    public function products(): HasMany
    {
        return $this->hasMany(Product::class);
    }
}
