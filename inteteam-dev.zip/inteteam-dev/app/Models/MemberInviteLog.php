<?php

namespace App\Models;

use Illuminate\Database\Eloquent\Model;
use Illuminate\Database\Eloquent\Relations\BelongsTo;

class MemberInviteLog extends Model
{
    protected $fillable = [
        'invited_id', 'inviting_id'
    ];
    protected $casts = [
        'created_at' => 'datetime:d/m/Y H:i:s',
        'updated_at' => 'datetime:d/m/Y H:i:s',
    ];

    public function invitedUser(): BelongsTo
    {
        return $this->belongsTo(User::class, 'invited_id', 'id');
    }

    public function invitingUser(): BelongsTo
    {
        return $this->belongsTo(User::class, 'inviting_id', 'id');
    }
}
