<?php

namespace App\Models;

use Illuminate\Database\Eloquent\Model;

class Plan extends Model
{
    protected $fillable = [
        'name',
        'price',
        'description',
        'stripe_plan_id',
    ];
    protected $casts = [
        'created_at' => 'datetime:d/m/Y H:i:s',
        'updated_at' => 'datetime:d/m/Y H:i:s',
    ];
    public function getFormattedPriceInCentsAttribute(): float|int
    {
        return str_replace('£', '', $this->price) * 100;
    }
}
