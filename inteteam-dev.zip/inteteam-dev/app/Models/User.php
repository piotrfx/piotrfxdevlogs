<?php

namespace App\Models;

use Illuminate\Contracts\Auth\MustVerifyEmail;
use Illuminate\Database\Eloquent\Collection;
use Illuminate\Database\Eloquent\Factories\HasFactory;
use Illuminate\Database\Eloquent\Relations\HasMany;
use Illuminate\Database\Eloquent\Relations\HasOne;
use Illuminate\Foundation\Auth\User as Authenticatable;
use Illuminate\Notifications\Notifiable;
use Laravel\Cashier\Billable;
use Spatie\Permission\Traits\HasRoles;

class User extends Authenticatable implements MustVerifyEmail
{
    use HasFactory, Notifiable, Billable, HasRoles;

    /**
     * The attributes that are mass assignable.
     *
     * @var array
     */
    protected $fillable = [
        'first_name',
        'last_name',
        'user_name',
        'email',
        'password',
        'ewallet',
        'invite',
        'personality'
    ];

    /**
     * The attributes that should be hidden for arrays.
     *
     * @var array
     */
    protected $hidden = [
        'password',
        'remember_token',
        'stripe_id',
        'card_brand',
        'card_last_four',
        'hash'
    ];

    /**
     * The attributes that should be cast to native types.
     *
     * @var array
     */
    protected $casts = [
        'email_verified_at' => 'datetime:d/m/Y H:i:s',
        'created_at'        => 'datetime: d/m/Y H:i:s',
        'updated_at'        => 'datetime: d/m/Y H:i:s'
    ];
    protected $appends = ['full_name'];
    protected $with = ['profile'];

    public function getFullNameAttribute(): string
    {
        return "{$this->first_name} {$this->last_name}";
    }

    public function wallet(): HasOne
    {
        return $this->hasOne(Wallet::class);
    }
    public function invite(): HasMany
    {
        return $this->hasMany(MemberInvite::class);
    }
    public function authenticationLog(): HasMany
    {
        return $this->hasMany(AuthenticationLog::class);
    }

    public function postComment(): HasMany
    {
        return $this->hasMany(PostComment::class);
    }

    public function activityLog(): HasMany
    {
        return $this->hasMany(ActivityLog::class);
    }

    public function profile(): HasOne
    {
        return $this->hasOne(UserProfile::class);
    }

    public function deliveryAddresses(): HasMany
    {
        return $this->hasMany(UserDeliveryAddress::class);
    }

    public function defaultDeliveryAddress()
    {
        return $this->deliveryAddresses()->where('is_default', '=', 1)->first();
    }

    public function lastLogins(): Collection
    {
        return $this->authenticationLog()->latest()->take(10)->get();
    }

    public function activityLogs(): Collection
    {
        return $this->activityLog()->latest()->take(10)->get();
    }

    public function lastComments(): Collection
    {
        return $this->postComment()->latest()->take(10)->get();
    }

    public function tickets(): HasMany
    {
        return $this->hasMany(SupportTicket::class, 'user_id', 'id');
    }

    public function setPasswordAttribute($password)
    {
        $this->attributes['password'] = bcrypt($password);
    }

    public function payments(): HasMany
    {
        return $this->hasMany(Payment::class);
    }
    public function chatMessages(): HasMany
    {
        return $this->hasMany(ChatMessage::class, 'to', 'id');
    }
}
