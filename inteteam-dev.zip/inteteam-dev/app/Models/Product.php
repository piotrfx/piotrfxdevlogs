<?php

namespace App\Models;

use App\Casts\ProductPriceCast;
use Gloudemans\Shoppingcart\CanBeBought;
use Gloudemans\Shoppingcart\Contracts\Buyable;
use Illuminate\Database\Eloquent\Factories\HasFactory;
use Illuminate\Database\Eloquent\Model;
use Illuminate\Database\Eloquent\Relations\BelongsTo;
use Illuminate\Database\Eloquent\Relations\HasMany;
use Illuminate\Support\Str;

class Product extends Model implements Buyable
{
    use HasFactory, CanBeBought;

    protected $fillable = [
        'name',
        'short_description',
        'long_description',
        'slug',
        'image_path',
        'status',
        'content',
        'user_id',
        'price',
        'available_at',
        'product_category_id',
        'product_type_id',
        'qty',
        'sku',
        'supplier_id',
        'colour',
        'expiry_date',
        'tax'
    ];
    protected $dates = [
        'available_at'
    ];

    protected $casts = [
        'price'        => ProductPriceCast::class,
        'available_at' => 'date:d/m/Y',
        'created_at'   => 'datetime:d/m/Y H:i:s',
        'updated_at'   => 'datetime:d/m/Y H:i:s',
    ];

    public function productCategory(): BelongsTo
    {
        return $this->belongsTo(ProductCategory::class);
    }

    public function productType(): BelongsTo
    {
        return $this->belongsTo(ProductType::class);
    }

    public function productSupplier(): BelongsTo
    {
        return $this->belongsTo(Supplier::class, 'supplier_id', 'id');
    }

    public function productImages(): HasMany
    {
        return $this->hasMany(ProductImage::class);
    }

    public function user(): BelongsTo
    {
        return $this->belongsTo(User::class);
    }

    public function getPriceAsIntegerAttribute(): string
    {
        $remove = Str::remove('£', $this->price);
        $remove = Str::remove(',', $remove);
        return Str::remove('.', $remove);
    }

    public function getBuyableIdentifier($options = null)
    {
        return $this->id;
    }

    public function getBuyableDescription($options = null)
    {
        return $this->name;
    }

    public function getBuyablePrice($options = null)
    {
        return $this->price;
    }

    public function getBuyableWeight($options = null)
    {
        return $this->weight;
    }

    public function getPriceAttribute()
    {
        return $this->price * $this->tax;
    }
}
