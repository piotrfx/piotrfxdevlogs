<?php

namespace App\Policies\User\Member\Support;

use App\Models\SupportTicket;
use App\Models\User;
use Illuminate\Auth\Access\HandlesAuthorization;

class TicketPolicy
{
    use HandlesAuthorization;

    public function __construct()
    {
        //
    }

    /**
     * Determine whether the user can view any support tickets.
     *
     * @param  User  $user
     * @return bool
     */
    public function viewAny(User $user)
    {
        //
    }

    /**
     * Determine whether the user can view the support ticket.
     *
     * @param  User  $user
     * @param  SupportTicket  $supportTicket
     * @return bool
     */
    public function view(User $user, SupportTicket $supportTicket)
    {
        return $user->id === $supportTicket->user_id;
    }

    /**
     * Determine whether the user can create support tickets.
     *
     * @param  User  $user
     * @return bool
     */
    public function create(User $user)
    {
        //
    }

    /**
     * Determine whether the user can update the support ticket.
     *
     * @param  User  $user
     * @param  SupportTicket  $supportTicket
     * @return bool
     */
    public function update(User $user, SupportTicket $supportTicket)
    {
        return $user->id === $supportTicket->user_id;
    }

    /**
     * Determine whether the user can delete the support ticket.
     *
     * @param  User  $user
     * @param  SupportTicket  $supportTicket
     * @return bool
     */
    public function delete(User $user, SupportTicket $supportTicket)
    {
        //
    }

    /**
     * Determine whether the user can restore the support ticket.
     *
     * @param  User  $user
     * @param  SupportTicket  $supportTicket
     * @return bool
     */
    public function restore(User $user, SupportTicket $supportTicket)
    {
        //
    }

    /**
     * Determine whether the user can permanently delete the support ticket.
     *
     * @param  User  $user
     * @param  SupportTicket  $supportTicket
     * @return bool
     */
    public function forceDelete(User $user, SupportTicket $supportTicket)
    {
        //
    }
}
