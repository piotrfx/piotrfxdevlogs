<?php

namespace App\Listeners;

use Illuminate\Auth\Events\Login;

class LogSuccessfulLogin
{
    public function __construct()
    {
        //
    }

    public function handle(Login $event)
    {
        $event->user->authenticationLog()->create([
            'ip'      => \Request::getClientIp(),
            'agent'   => \Request::header('User-Agent'),
            'success' => 1
        ]);
    }
}
