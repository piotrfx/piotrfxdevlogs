<?php

namespace App\Listeners;

use App\Models\User;
use Illuminate\Auth\Events\Failed;

class LogFailedLogin
{
    public User $user;

    public function __construct()
    {

    }

    public function handle(Failed $event)
    {
        if ($event->user) {
            $event->user->authenticationLog()->create([
                'ip'      => \Request::getClientIp(),
                'agent'   => \Request::header('User-Agent'),
                'success' => 0
            ]);
        }

    }
}
