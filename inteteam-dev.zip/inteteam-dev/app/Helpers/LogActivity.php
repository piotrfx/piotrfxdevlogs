<?php


namespace App\Helpers;

use App\Models\ActivityLog as LogActivityModel;
use Request;

class LogActivity
{
    public static function addToLog($subject)
    {
        LogActivityModel::create([
            'subject' => $subject,
            'url'     => Request::fullUrl(),
            'method'  => Request::method(),
            'ip'      => Request::ip(),
            'agent'   => Request::header('User-Agent'),
            'user_id' => auth()->check() ? auth()->user()->id : null
        ]);
    }

    /**
     * @return LogActivityModel[]|\LaravelIdea\Helper\App\Models\_IH_ActivityLog_C
     */
    public static function logActivityList(): array|\LaravelIdea\Helper\App\Models\_IH_ActivityLog_C
    {
        return LogActivityModel::latest()->get();
    }
}
