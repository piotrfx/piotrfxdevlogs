<?php

namespace App\Observers\User\Member;

use App\Mail\User\Member\Invite;
use App\Models\MemberInvite;
use App\Notifications\User\Member\InviteUser;
use Illuminate\Support\Facades\Mail;
use Illuminate\Support\Str;

class InviteObserver
{
    /**
     * Handle the member invite "creating" event.
     *
     * @param  MemberInvite  $memberInvite
     */
    public function creating(MemberInvite $memberInvite)
    {
        $memberInvite->hash = Str::random('60');
        $memberInvite->user_id = auth()->user()->id;
    }

    /**
     * Handle the member invite "updating" event.
     *
     * @param  MemberInvite  $memberInvite
     */
    public function updating(MemberInvite $memberInvite)
    {
        //
    }

    /**
     * Handle the member invite "created" event.
     *
     * @param  MemberInvite  $memberInvite
     */
    public function created(MemberInvite $memberInvite)
    {
      $memberInvite->notify(new InviteUser($memberInvite, auth()->user()));
       // Mail::to($memberInvite->email)->send(new Invite($memberInvite, auth()->user()));
    }

    /**
     * Handle the member invite "updated" event.
     *
     * @param  MemberInvite  $memberInvite
     */
    public function updated(MemberInvite $memberInvite)
    {
        //
    }

    /**
     * Handle the member invite "deleted" event.
     *
     * @param  MemberInvite  $memberInvite
     */
    public function deleted(MemberInvite $memberInvite)
    {
        //
    }

    /**
     * Handle the member invite "restored" event.
     *
     * @param  MemberInvite  $memberInvite
     */
    public function restored(MemberInvite $memberInvite)
    {
        //
    }

    /**
     * Handle the member invite "force deleted" event.
     *
     * @param  MemberInvite  $memberInvite
     */
    public function forceDeleted(MemberInvite $memberInvite)
    {
        //
    }
}
