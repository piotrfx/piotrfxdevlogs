<?php

namespace App\Observers\User\Member;

use App\Models\SupportTicketMessage;

class SupportTicketMessageObserver
{
    /**
     * Handle the support ticket message "creating" event.
     *
     * @param  SupportTicketMessage  $supportTicketMessage
     */
    public function creating(SupportTicketMessage $supportTicketMessage)
    {
        $supportTicketMessage->user_id = auth()->user()->id;
    }

    /**
     * Handle the support ticket message "updating" event.
     *
     * @param  SupportTicketMessage  $supportTicketMessage
     */
    public function updating(SupportTicketMessage $supportTicketMessage)
    {
        //
    }

    /**
     * Handle the support ticket message "created" event.
     *
     * @param  SupportTicketMessage  $supportTicketMessage
     */
    public function created(SupportTicketMessage $supportTicketMessage)
    {
        //
    }

    /**
     * Handle the support ticket message "updated" event.
     *
     * @param  SupportTicketMessage  $supportTicketMessage
     */
    public function updated(SupportTicketMessage $supportTicketMessage)
    {
        //
    }

    /**
     * Handle the support ticket message "deleted" event.
     *
     * @param  SupportTicketMessage  $supportTicketMessage
     */
    public function deleted(SupportTicketMessage $supportTicketMessage)
    {
        //
    }

    /**
     * Handle the support ticket message "restored" event.
     *
     * @param  SupportTicketMessage  $supportTicketMessage
     */
    public function restored(SupportTicketMessage $supportTicketMessage)
    {
        //
    }

    /**
     * Handle the support ticket message "force deleted" event.
     *
     * @param  SupportTicketMessage  $supportTicketMessage
     */
    public function forceDeleted(SupportTicketMessage $supportTicketMessage)
    {
        //
    }
}
