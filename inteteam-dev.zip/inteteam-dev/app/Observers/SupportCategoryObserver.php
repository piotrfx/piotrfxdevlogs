<?php

namespace App\Observers;

use App\Models\SupportCategory;
use Illuminate\Support\Str;

class SupportCategoryObserver
{
    /**
     * Handle the support category "creating" event.
     *
     * @param  SupportCategory  $supportCategory
     */
    public function creating(SupportCategory $supportCategory)
    {
       $supportCategory->slug = Str::slug($supportCategory->name);
    }

    /**
     * Handle the support category "updating" event.
     *
     * @param  SupportCategory  $supportCategory
     */
    public function updating(SupportCategory $supportCategory)
    {
        $supportCategory->slug = Str::slug($supportCategory->name);
    }

    /**
     * Handle the support category "created" event.
     *
     * @param  SupportCategory  $supportCategory
     */
    public function created(SupportCategory $supportCategory)
    {
        //
    }

    /**
     * Handle the support category "updated" event.
     *
     * @param  SupportCategory  $supportCategory
     */
    public function updated(SupportCategory $supportCategory)
    {
        //
    }

    /**
     * Handle the support category "deleted" event.
     *
     * @param  SupportCategory  $supportCategory
     */
    public function deleted(SupportCategory $supportCategory)
    {
        //
    }

    /**
     * Handle the support category "restored" event.
     *
     * @param  SupportCategory  $supportCategory
     */
    public function restored(SupportCategory $supportCategory)
    {
        //
    }

    /**
     * Handle the support category "force deleted" event.
     *
     * @param  SupportCategory  $supportCategory
     */
    public function forceDeleted(SupportCategory $supportCategory)
    {
        //
    }
}
