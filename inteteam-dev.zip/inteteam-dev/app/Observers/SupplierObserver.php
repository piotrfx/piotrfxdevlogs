<?php

namespace App\Observers;

use App\Models\Supplier;
use Illuminate\Support\Str;

class SupplierObserver
{
    /**
     * Handle the supplier "creating" event.
     *
     * @param  Supplier  $supplier
     */
    public function creating(Supplier $supplier)
    {
        $supplier->slug = Str::slug($supplier->name);
    }

    /**
     * Handle the supplier "updating" event.
     *
     * @param  Supplier  $supplier
     */
    public function updating(Supplier $supplier)
    {
        $supplier->slug = Str::slug($supplier->name);
    }

    /**
     * Handle the supplier "created" event.
     *
     * @param  Supplier  $supplier
     */
    public function created(Supplier $supplier)
    {
        //
    }

    /**
     * Handle the supplier "updated" event.
     *
     * @param  Supplier  $supplier
     */
    public function updated(Supplier $supplier)
    {
        //
    }

    /**
     * Handle the supplier "deleted" event.
     *
     * @param  Supplier  $supplier
     */
    public function deleted(Supplier $supplier)
    {

    }

    /**
     * Handle the supplier "restored" event.
     *
     * @param  Supplier  $supplier
     */
    public function restored(Supplier $supplier)
    {
        //
    }

    /**
     * Handle the supplier "force deleted" event.
     *
     * @param  Supplier  $supplier
     */
    public function forceDeleted(Supplier $supplier)
    {
        //
    }
}
