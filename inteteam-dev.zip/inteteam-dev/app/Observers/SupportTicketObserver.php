<?php

namespace App\Observers;

use App\Mail\System\Support\NewTicket;
use App\Models\SupportStatus;
use App\Models\SupportTicket;
use Illuminate\Support\Str;

class SupportTicketObserver
{
    /**
     * Handle the support ticket "creating" event.
     *
     * @param  SupportTicket  $supportTicket
     */
    public function creating(SupportTicket $supportTicket)
    {
        $supportTicket->uuid = Str::uuid();
        $supportTicket->support_status_id = SupportStatus::where('slug','=','open')->first()->id;
    }

    /**
     * Handle the support ticket "updating" event.
     *
     * @param  SupportTicket  $supportTicket
     */
    public function updating(SupportTicket $supportTicket)
    {
        //
    }

    /**
     * Handle the support ticket "created" event.
     *
     * @param  SupportTicket  $supportTicket
     */
    public function created(SupportTicket $supportTicket)
    {
        $supportTicket->update(
            [
                'ticket_id' => 'it-'.now()->year.'-'.$supportTicket->id
            ]
        );
        //notifikacja
        \Mail::to(config('mail.support'))->send(new NewTicket($supportTicket));
    }

    /**
     * Handle the support ticket "updated" event.
     *
     * @param  SupportTicket  $supportTicket
     */
    public function updated(SupportTicket $supportTicket)
    {
        //
    }

    /**
     * Handle the support ticket "deleted" event.
     *
     * @param  SupportTicket  $supportTicket
     */
    public function deleted(SupportTicket $supportTicket)
    {
        //
    }

    /**
     * Handle the support ticket "restored" event.
     *
     * @param  SupportTicket  $supportTicket
     */
    public function restored(SupportTicket $supportTicket)
    {
        //
    }

    /**
     * Handle the support ticket "force deleted" event.
     *
     * @param  SupportTicket  $supportTicket
     */
    public function forceDeleted(SupportTicket $supportTicket)
    {
        //
    }
}
