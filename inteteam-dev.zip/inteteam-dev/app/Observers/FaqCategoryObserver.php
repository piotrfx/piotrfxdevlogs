<?php

namespace App\Observers;

use App\Models\FaqCategory;
use Illuminate\Support\Str;

class FaqCategoryObserver
{
    /**
     * Handle the faq category "creating" event.
     *
     * @param  FaqCategory  $faqCategory
     */
    public function creating(FaqCategory $faqCategory)
    {
        $faqCategory->slug = Str::slug($faqCategory->name);
    }

    /**
     * Handle the faq category "updating" event.
     *
     * @param  FaqCategory  $faqCategory
     */
    public function updating(FaqCategory $faqCategory)
    {
        $faqCategory->slug = Str::slug($faqCategory->name);
    }

    /**
     * Handle the faq category "created" event.
     *
     * @param  FaqCategory  $faqCategory
     */
    public function created(FaqCategory $faqCategory)
    {
        //
    }

    /**
     * Handle the faq category "updated" event.
     *
     * @param  FaqCategory  $faqCategory
     */
    public function updated(FaqCategory $faqCategory)
    {
        //
    }

    /**
     * Handle the faq category "deleted" event.
     *
     * @param  FaqCategory  $faqCategory
     */
    public function deleted(FaqCategory $faqCategory)
    {
        //
    }

    /**
     * Handle the faq category "restored" event.
     *
     * @param  FaqCategory  $faqCategory
     */
    public function restored(FaqCategory $faqCategory)
    {
        //
    }

    /**
     * Handle the faq category "force deleted" event.
     *
     * @param  FaqCategory  $faqCategory
     */
    public function forceDeleted(FaqCategory $faqCategory)
    {
        //
    }
}
