<?php

namespace App\Observers;

use App\Models\Page;
use Illuminate\Support\Str;

class PageObserver
{
    /**
     * Handle the page "creating" event.
     *
     * @param  Page  $page
     */
    public function creating(Page $page)
    {
       $page->slug= Str::slug($page->title);
    }

    /**
     * Handle the page "updating" event.
     *
     * @param  Page  $page
     */
    public function updating(Page $page)
    {
        $page->slug= Str::slug($page->title);
    }

    /**
     * Handle the page "created" event.
     *
     * @param  Page  $page
     */
    public function created(Page $page)
    {
        //
    }

    /**
     * Handle the page "updated" event.
     *
     * @param  Page  $page
     */
    public function updated(Page $page)
    {
        //
    }

    /**
     * Handle the page "deleted" event.
     *
     * @param  Page  $page
     */
    public function deleted(Page $page)
    {
        //
    }

    /**
     * Handle the page "restored" event.
     *
     * @param  Page  $page
     */
    public function restored(Page $page)
    {
        //
    }

    /**
     * Handle the page "force deleted" event.
     *
     * @param  Page  $page
     */
    public function forceDeleted(Page $page)
    {
        //
    }
}
