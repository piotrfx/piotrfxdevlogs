<?php

namespace App\Observers;

use App\Models\ProductCategory;
use Illuminate\Support\Str;

class ProductCategoryObserver
{
    /**
     * Handle the product category "creating" event.
     *
     * @param  ProductCategory  $productCategory
     */
    public function creating(ProductCategory $productCategory)
    {
        $productCategory->slug = Str::slug($productCategory->title);
    }

    /**
     * Handle the product category "updating" event.
     *
     * @param  ProductCategory  $productCategory
     */
    public function updating(ProductCategory $productCategory)
    {
        $productCategory->slug = Str::slug($productCategory->title);
    }

    /**
     * Handle the product category "created" event.
     *
     * @param  ProductCategory  $productCategory
     */
    public function created(ProductCategory $productCategory)
    {
        //
    }

    /**
     * Handle the product category "updated" event.
     *
     * @param  ProductCategory  $productCategory
     */
    public function updated(ProductCategory $productCategory)
    {
        //
    }

    /**
     * Handle the product category "deleted" event.
     *
     * @param  ProductCategory  $productCategory
     */
    public function deleted(ProductCategory $productCategory)
    {
        \Storage::delete($productCategory->image_path);
    }

    /**
     * Handle the product category "restored" event.
     *
     * @param  ProductCategory  $productCategory
     */
    public function restored(ProductCategory $productCategory)
    {
        //
    }

    /**
     * Handle the product category "force deleted" event.
     *
     * @param  ProductCategory  $productCategory
     */
    public function forceDeleted(ProductCategory $productCategory)
    {
        //
    }
}
