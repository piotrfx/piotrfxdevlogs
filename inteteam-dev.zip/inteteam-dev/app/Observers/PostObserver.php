<?php

namespace App\Observers;

use App\Models\Post;
use Illuminate\Support\Str;

class PostObserver
{
    /**
     * Handle the post "creating" event.
     *
     * @param  Post  $post
     */
    public function creating(Post $post)
    {
        $post->slug = Str::slug($post->title);
    }

    /**
     * Handle the post "updating" event.
     *
     * @param  Post  $post
     */
    public function updating(Post $post)
    {
        $post->slug = Str::slug($post->title);
    }

    /**
     * Handle the post "created" event.
     *
     * @param  Post  $post
     */
    public function created(Post $post)
    {
        //
    }

    /**
     * Handle the post "updated" event.
     *
     * @param  Post  $post
     */
    public function updated(Post $post)
    {
        //
    }

    /**
     * Handle the post "deleted" event.
     *
     * @param  Post  $post
     */
    public function deleted(Post $post)
    {
        \Storage::delete($post->image_path);
    }

    /**
     * Handle the post "restored" event.
     *
     * @param  Post  $post
     */
    public function restored(Post $post)
    {
        //
    }

    /**
     * Handle the post "force deleted" event.
     *
     * @param  Post  $post
     */
    public function forceDeleted(Post $post)
    {
        //
    }
}
