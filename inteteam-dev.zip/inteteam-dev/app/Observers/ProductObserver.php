<?php

namespace App\Observers;

use App\Models\Product;
use Illuminate\Support\Str;

class ProductObserver
{
    /**
     * Handle the product "creating" event.
     *
     * @param  Product  $product
     */
    public function creating(Product $product)
    {
        $product->slug = Str::slug($product->name);
        $product->user_id = (auth()->user()->id) ?? 1;
    }

    /**
     * Handle the product "updating" event.
     *
     * @param  Product  $product
     */
    public function updating(Product $product)
    {
        $product->slug = Str::slug($product->name);
    }

    /**
     * Handle the product "created" event.
     *
     * @param  Product  $product
     */
    public function created(Product $product)
    {
        //
    }

    /**
     * Handle the product "updated" event.
     *
     * @param  Product  $product
     */
    public function updated(Product $product)
    {
        //
    }

    /**
     * Handle the product "deleted" event.
     *
     * @param  Product  $product
     */
    public function deleted(Product $product)
    {
        //
    }

    /**
     * Handle the product "restored" event.
     *
     * @param  Product  $product
     */
    public function restored(Product $product)
    {
        //
    }

    /**
     * Handle the product "force deleted" event.
     *
     * @param  Product  $product
     */
    public function forceDeleted(Product $product)
    {
        if ($product->productImages()) {
            foreach ($product->productImages() as $image) {
                \Storage::delete($image->image_path);
                $image->delete();
            }
        }
        \Storage::delete($product->image_path);
    }
}
