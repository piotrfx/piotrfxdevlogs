<?php

namespace App\View\Components\Users\Navbar;

use Illuminate\View\Component;

class UnreadMessages extends Component
{
    public $messages;
    /**
     * Create a new component instance.
     *
     * @return void
     */
    public function __construct()
    {
        $this->messages = auth()->user()->chatMessages->where('read', false);
    }

    /**
     * Get the view / contents that represent the component.
     *
     * @return \Illuminate\Contracts\View\View|\Closure|string
     */
    public function render()
    {
        return view('components.users.navbar.unread-messages');
    }
}
