<?php

namespace App\Jobs\StripeWebhooks;

use App\Models\User;
use App\Notifications\Admins\Stripe\UserUpdateSubscriptionNotification;
use App\Notifications\Business\Stripe\CustomerSubscriptionUpdatedNotification;
use Illuminate\Bus\Queueable;
use Illuminate\Contracts\Queue\ShouldQueue;
use Illuminate\Foundation\Bus\Dispatchable;
use Illuminate\Queue\InteractsWithQueue;
use Illuminate\Queue\SerializesModels;
use Spatie\WebhookClient\Models\WebhookCall;
use Illuminate\Support\Facades\Notification;

class CustomerSubscriptionUpdatedJob implements ShouldQueue
{
    use Dispatchable, InteractsWithQueue, Queueable, SerializesModels;

    /** @var \Spatie\WebhookClient\Models\WebhookCall */

    /** @var \Spatie\WebhookClient\Models\WebhookCall */

    public $webhookCall;

    /**
     * ChargeSucceededJob constructor.
     * @param  WebhookCall  $webhookCall
     */
    public function __construct(WebhookCall $webhookCall)
    {
        $this->webhookCall = $webhookCall;
    }
    /**
     * Execute the job.
     *
     * @return void
     */
    public function handle()
    {
        $charge = $this->webhookCall->payload['data']['object'];
        $user = User::where('stripe_id', $charge['customer'])->first();
        if ($user) {
            $user->notify(new CustomerSubscriptionUpdatedNotification());
        }
        Notification::route('mail', config('mail.notifications.address'))
            ->notify(new UserUpdateSubscriptionNotification());
    }
}
