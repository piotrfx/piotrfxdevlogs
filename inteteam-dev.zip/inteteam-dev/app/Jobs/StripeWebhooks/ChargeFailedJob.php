<?php

namespace App\Jobs\StripeWebhooks;

use App\Models\User;
use App\Notifications\Business\Stripe\ChargeFailedNotification;
use Illuminate\Support\Facades\Notification;
use App\Notifications\Admins\Stripe\PaymentFiledNotification;
use Illuminate\Bus\Queueable;
use Illuminate\Contracts\Queue\ShouldQueue;
use Illuminate\Foundation\Bus\Dispatchable;
use Illuminate\Queue\InteractsWithQueue;
use Illuminate\Queue\SerializesModels;
use Spatie\WebhookClient\Models\WebhookCall;

class ChargeFailedJob implements ShouldQueue
{
    use Dispatchable, InteractsWithQueue, Queueable, SerializesModels;

    /** @var \Spatie\WebhookClient\Models\WebhookCall */

    public $webhookCall;

    /**
     * ChargeSucceededJob constructor.
     * @param  WebhookCall  $webhookCall
     */
    public function __construct(WebhookCall $webhookCall)
    {
        $this->webhookCall = $webhookCall;
    }

    /**
     * Execute the job.
     *
     * @return void
     */
    public function handle()
    {
        $charge = $this->webhookCall->payload['data']['object'];
        $user = User::where('stripe_id', $charge['customer'])->first();
        if ($user) {
            $user->notify(new ChargeFailedNotification());

        }
        Notification::route('mail', config('mail.notifications.address'))
            ->notify(new PaymentFiledNotification());
    }
}
